/// A focus session's lifecycle state — Sprint V2-03 Task 1.
enum FocusSessionStatus { idle, running, paused, completed }

/// An immutable snapshot of a focus session — Sprint V2-03 Task 1.
///
/// Deliberately built on absolute timestamps ([startTime], [pausedAt])
/// rather than a live-decrementing counter: [remainingTime] is always
/// *computed* from "now" versus [startTime]/[pausedDuration], never
/// stored as its own field. This is what makes Task 5's persistence
/// requirement work correctly — reloading the same
/// duration/startTime/pausedDuration after an app restart and
/// recomputing [remainingTime] against the *current* clock
/// automatically accounts for however much time passed while the app
/// was closed, with no special restart-handling logic needed anywhere.
///
/// No `copyWith`: every transition (see `focus_service.dart`) already
/// knows every field's new value, so a partial-update helper would add
/// the classic "how do I explicitly set a nullable field back to null"
/// ambiguity for no real benefit here — unlike `Document`/`Task`, which
/// have many more fields and genuinely benefit from one.
class FocusSession {
  const FocusSession({
    this.durationMinutes = 25,
    this.startTime,
    this.status = FocusSessionStatus.idle,
    this.pausedDuration = Duration.zero,
    this.pausedAt,
  });

  /// The not-yet-started, nothing-to-restore state.
  static const FocusSession idle = FocusSession();

  /// The session's intended total length.
  final int durationMinutes;

  /// When the session began. Null only while [status] is
  /// [FocusSessionStatus.idle].
  final DateTime? startTime;

  final FocusSessionStatus status;

  /// Total duration of every *past, completed* pause (each one ended by
  /// a resume) — does not include any currently-ongoing pause. See
  /// [remainingTime] for how this and [pausedAt] combine.
  final Duration pausedDuration;

  /// When the current pause began, or null when not currently paused.
  final DateTime? pausedAt;

  bool get isIdle => status == FocusSessionStatus.idle;
  bool get isRunning => status == FocusSessionStatus.running;
  bool get isPaused => status == FocusSessionStatus.paused;
  bool get isCompleted => status == FocusSessionStatus.completed;

  Duration get totalDuration => Duration(minutes: durationMinutes);

  /// Time left in the session, right now.
  ///
  /// While [isPaused], this is frozen at whatever it was the moment the
  /// pause began (verified by hand-tracing before writing this: pausing
  /// at 5 elapsed minutes and letting 10 real minutes pass while paused
  /// still reports 20 minutes remaining out of 25; resuming and
  /// checking immediately still reports 20; 5 more *active* minutes
  /// then correctly brings it to 15).
  Duration get remainingTime {
    if (status == FocusSessionStatus.idle) return totalDuration;
    if (status == FocusSessionStatus.completed) return Duration.zero;
    final start = startTime;
    if (start == null) return totalDuration;
    final referenceTime =
        status == FocusSessionStatus.paused ? (pausedAt ?? DateTime.now()) : DateTime.now();
    final activeElapsed = referenceTime.difference(start) - pausedDuration;
    final remaining = totalDuration - activeElapsed;
    return remaining.isNegative ? Duration.zero : remaining;
  }

  /// 0.0 (just started) to 1.0 (time's up), for a progress indicator.
  ///
  /// Computed via explicit comparisons, not `.clamp()` — `num.clamp`
  /// returns `num`, not the receiver's own type, which has already
  /// caused a real type-mismatch bug earlier in this project
  /// (search_service.dart's snippetFor); avoiding it here rather than
  /// re-risking the same issue.
  double get progress {
    final totalSeconds = totalDuration.inSeconds;
    if (totalSeconds == 0) return 0.0;
    final elapsedSeconds = totalSeconds - remainingTime.inSeconds;
    final ratio = elapsedSeconds / totalSeconds;
    if (ratio < 0) return 0.0;
    if (ratio > 1) return 1.0;
    return ratio;
  }

  Map<String, dynamic> toJson() => {
        'durationMinutes': durationMinutes,
        'startTime': startTime?.toIso8601String(),
        'status': status.name,
        'pausedSeconds': pausedDuration.inSeconds,
        'pausedAt': pausedAt?.toIso8601String(),
      };

  factory FocusSession.fromJson(Map<String, dynamic> json) {
    return FocusSession(
      durationMinutes: json['durationMinutes'] as int,
      startTime: json['startTime'] == null
          ? null
          : DateTime.parse(json['startTime'] as String),
      status: FocusSessionStatus.values.byName(json['status'] as String),
      pausedDuration: Duration(seconds: (json['pausedSeconds'] as int?) ?? 0),
      pausedAt: json['pausedAt'] == null
          ? null
          : DateTime.parse(json['pausedAt'] as String),
    );
  }
}
