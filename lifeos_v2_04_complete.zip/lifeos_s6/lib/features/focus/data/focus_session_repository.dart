import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'focus_session_model.dart';

/// Persists the current focus session — Sprint V2-03 Task 5.
///
/// Abstract, matching every other repository in this project
/// (`DocumentRepository`, `TasksRepository`,
/// `QuickClipboardRepository`) — Presentation/Logic code depends on
/// this interface, never on [FileFocusSessionRepository] directly.
abstract class FocusSessionRepository {
  /// The persisted session, or null if none has ever been saved.
  Future<FocusSession?> read();

  /// Overwrites the persisted session with [session].
  Future<void> write(FocusSession session);
}

/// Stores the session as a single JSON file in the platform's app
/// documents directory — same shape as V2-02's
/// `FileQuickClipboardRepository`, for the same reasons: this sprint's
/// regression check forbids SQLite changes, and one small record
/// doesn't need a table. Also deliberately not `FileSystemService`'s
/// vault-adapter abstraction (Sprint 15) — that's scoped to
/// vault-relative `Document`s; a focus session has no vault concept.
class FileFocusSessionRepository implements FocusSessionRepository {
  const FileFocusSessionRepository();

  Future<File> _resolveFile() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/focus_session.json');
  }

  @override
  Future<FocusSession?> read() async {
    final file = await _resolveFile();
    if (!await file.exists()) return null;
    final raw = await file.readAsString();
    if (raw.trim().isEmpty) return null;
    try {
      final json = jsonDecode(raw) as Map<String, dynamic>;
      return FocusSession.fromJson(json);
    } on FormatException {
      // A corrupted or partial write (e.g. the app was killed mid-write,
      // exactly the "accidental restart" scenario Task 5 is for) — degrade
      // to "nothing to restore" rather than crash on the next launch.
      return null;
    }
  }

  @override
  Future<void> write(FocusSession session) async {
    final file = await _resolveFile();
    await file.writeAsString(jsonEncode(session.toJson()));
  }
}
