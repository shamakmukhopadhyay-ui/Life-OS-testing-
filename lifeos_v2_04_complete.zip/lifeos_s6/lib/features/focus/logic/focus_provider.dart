import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/focus_session_model.dart';
import '../data/focus_session_repository.dart';
import 'focus_service.dart';

final focusSessionRepositoryProvider = Provider<FocusSessionRepository>((
  ref,
) {
  return const FileFocusSessionRepository();
});

/// Holds the current focus session, ticks it while running, and
/// persists every real transition — Sprint V2-03 Task 3.
///
/// Every method here is a thin call-through to [FocusService] plus
/// state/persistence bookkeeping — no timer *math* lives here, only
/// timer *scheduling* (a `Timer.periodic` to drive the live countdown
/// display). That split is what Task 7's "provider only connects
/// layers" means concretely: this class connects a `Timer` to
/// [FocusService]'s pure transitions and to [FocusSessionRepository],
/// but never itself decides what a tick *means* for the session.
class FocusNotifier extends AsyncNotifier<FocusSession> {
  Timer? _ticker;

  @override
  Future<FocusSession> build() async {
    ref.onDispose(() => _ticker?.cancel());
    final repo = ref.read(focusSessionRepositoryProvider);
    final restored = await repo.read() ?? FocusSession.idle;
    // Catches the case where the app was closed while a session was
    // running and enough real time passed that it's already finished —
    // restoring "restart recovery" (Task 5) shouldn't restore a session
    // that's actually over.
    final checked = FocusService.checkForCompletion(restored);
    if (!identical(checked, restored)) {
      await repo.write(checked);
    }
    if (checked.isRunning) _startTicking();
    return checked;
  }

  void _startTicking() {
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  void _stopTicking() {
    _ticker?.cancel();
    _ticker = null;
  }

  void _tick() {
    final current = state.valueOrNull;
    if (current == null || !current.isRunning) {
      _stopTicking();
      return;
    }
    final checked = FocusService.checkForCompletion(current);
    if (checked.isCompleted) {
      _stopTicking();
      state = AsyncValue.data(checked);
      unawaited(_persist(checked));
      return;
    }
    // remainingTime/progress are computed against DateTime.now(), not
    // stored fields, so reassigning the *same* FocusSession instance
    // wouldn't register as a change (it has no custom ==, so Riverpod's
    // default equality is identity-based). Building a field-identical
    // *new* instance is purely so the countdown repaints every second —
    // not persisted, since FocusSession's own doc comment is exactly
    // why a stale on-disk startTime/pausedDuration still recomputes
    // correctly after a restart without needing a fresh write every tick.
    state = AsyncValue.data(
      FocusSession(
        durationMinutes: current.durationMinutes,
        startTime: current.startTime,
        status: current.status,
        pausedDuration: current.pausedDuration,
        pausedAt: current.pausedAt,
      ),
    );
  }

  Future<void> _persist(FocusSession session) {
    return ref.read(focusSessionRepositoryProvider).write(session);
  }

  Future<void> start(int durationMinutes) async {
    final session = FocusService.start(durationMinutes);
    state = AsyncValue.data(session);
    _startTicking();
    await _persist(session);
  }

  Future<void> pause() async {
    final current = state.valueOrNull;
    if (current == null) return;
    final session = FocusService.pause(current);
    state = AsyncValue.data(session);
    _stopTicking();
    await _persist(session);
  }

  Future<void> resume() async {
    final current = state.valueOrNull;
    if (current == null) return;
    final session = FocusService.resume(current);
    state = AsyncValue.data(session);
    _startTicking();
    await _persist(session);
  }

  Future<void> stop() async {
    _stopTicking();
    final session = FocusService.stop(state.valueOrNull ?? FocusSession.idle);
    state = AsyncValue.data(session);
    await _persist(session);
  }

  Future<void> reset() async {
    _stopTicking();
    final session =
        FocusService.reset(state.valueOrNull ?? FocusSession.idle);
    state = AsyncValue.data(session);
    await _persist(session);
  }
}

final focusProvider = AsyncNotifierProvider<FocusNotifier, FocusSession>(
  FocusNotifier.new,
);
