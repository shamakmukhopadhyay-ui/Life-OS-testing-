import '../data/focus_session_model.dart';

/// Owns focus-session transition logic — Sprint V2-03 Task 2.
///
/// Static and dependency-free, same shape as every other service this
/// project has built (`MetadataQueryService`, `SearchService`,
/// `VaultSyncService`): every method is a pure function of the
/// [FocusSession] handed to it, returning a new one. No `Timer`, no
/// Riverpod, no file I/O — those live in `focus_provider.dart`, which
/// delegates every actual state transition here. This split is what
/// makes "UI contains no timer business logic" true in the strong
/// sense: the logic isn't just kept out of the widget, it's kept out
/// of the Riverpod layer too, in a form that's directly unit-testable
/// with no widget/provider harness at all.
class FocusService {
  FocusService._(); // not instantiable

  /// Begins a new session. Valid from any state — starting always
  /// begins fresh, regardless of whatever the previous session's state
  /// was (idle, completed, or an abandoned running/paused one).
  static FocusSession start(int durationMinutes) {
    return FocusSession(
      durationMinutes: durationMinutes,
      startTime: DateTime.now(),
      status: FocusSessionStatus.running,
    );
  }

  /// Running → paused. No-op (returns [session] unchanged) if not
  /// currently running.
  static FocusSession pause(FocusSession session) {
    if (!session.isRunning) return session;
    return FocusSession(
      durationMinutes: session.durationMinutes,
      startTime: session.startTime,
      status: FocusSessionStatus.paused,
      pausedDuration: session.pausedDuration,
      pausedAt: DateTime.now(),
    );
  }

  /// Paused → running, folding the just-ended pause's length into
  /// [FocusSession.pausedDuration] so [FocusSession.remainingTime]
  /// keeps counting from exactly where it was frozen. No-op if not
  /// currently paused.
  static FocusSession resume(FocusSession session) {
    if (!session.isPaused) return session;
    final pausedAt = session.pausedAt;
    final additionalPause =
        pausedAt == null ? Duration.zero : DateTime.now().difference(pausedAt);
    return FocusSession(
      durationMinutes: session.durationMinutes,
      startTime: session.startTime,
      status: FocusSessionStatus.running,
      pausedDuration: session.pausedDuration + additionalPause,
      pausedAt: null,
    );
  }

  /// Ends the session early, from either running or paused, back to
  /// idle. The abandoned session's own timing isn't preserved — Task 6
  /// only asks for "Stop", not for keeping a record of stopped
  /// sessions.
  static FocusSession stop(FocusSession session) => FocusSession.idle;

  /// Clears back to idle — the way out of [FocusSessionStatus.completed]
  /// (or any other state) to a fresh, ready-to-start slate.
  static FocusSession reset(FocusSession session) => FocusSession.idle;

  /// If [session] is running and its time has actually run out,
  /// returns it transitioned to completed; otherwise returns it
  /// unchanged.
  ///
  /// Not a user-invoked transition — called by the provider's periodic
  /// tick and when restoring a persisted session, both of which need
  /// to notice "this session's clock already ran out" without the user
  /// having pressed anything.
  static FocusSession checkForCompletion(FocusSession session) {
    if (session.isRunning && session.remainingTime == Duration.zero) {
      return FocusSession(
        durationMinutes: session.durationMinutes,
        startTime: session.startTime,
        status: FocusSessionStatus.completed,
        pausedDuration: session.pausedDuration,
      );
    }
    return session;
  }
}
