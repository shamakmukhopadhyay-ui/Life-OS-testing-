import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/focus_session_model.dart';
import '../../logic/focus_provider.dart';

const _defaultFocusMinutes = 25;

/// Replaces the Focus Mode placeholder on Home — Sprint V2-03 Task 4.
///
/// Every button here calls straight through to [FocusNotifier] — no
/// timer math and no state decisions live in this widget, which is
/// what "UI contains no timer business logic" (Task 7) means in
/// practice, not just in principle. Fixed at a 25-minute session (this
/// project's other new-feature MVPs — Quick Clipboard, V2-02 — also
/// shipped without a configuration UI); a duration picker isn't one of
/// this sprint's listed requirements.
class FocusCard extends ConsumerWidget {
  const FocusCard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final sessionAsync = ref.watch(focusProvider);
    final notifier = ref.read(focusProvider.notifier);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: sessionAsync.when(
          loading: () => const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Center(child: CircularProgressIndicator()),
          ),
          error: (error, _) => Text(
            'Could not load Focus Mode',
            style: theme.textTheme.bodyMedium,
          ),
          data: (session) => _FocusBody(session: session, notifier: notifier),
        ),
      ),
    );
  }
}

class _FocusBody extends StatelessWidget {
  const _FocusBody({required this.session, required this.notifier});

  final FocusSession session;
  final FocusNotifier notifier;

  String _formatDuration(Duration duration) {
    final minutes = duration.inMinutes.remainder(60).toString().padLeft(
          2,
          '0',
        );
    final seconds = duration.inSeconds.remainder(60).toString().padLeft(
          2,
          '0',
        );
    return '$minutes:$seconds';
  }

  List<Widget> _buttons() {
    if (session.isRunning) {
      return [
        OutlinedButton.icon(
          onPressed: notifier.pause,
          icon: const Icon(Icons.pause),
          label: const Text('Pause'),
        ),
        const SizedBox(width: 8),
        OutlinedButton.icon(
          onPressed: notifier.stop,
          icon: const Icon(Icons.stop),
          label: const Text('Stop'),
        ),
      ];
    }
    if (session.isPaused) {
      return [
        FilledButton.icon(
          onPressed: notifier.resume,
          icon: const Icon(Icons.play_arrow),
          label: const Text('Resume'),
        ),
        const SizedBox(width: 8),
        OutlinedButton.icon(
          onPressed: notifier.stop,
          icon: const Icon(Icons.stop),
          label: const Text('Stop'),
        ),
      ];
    }
    if (session.isCompleted) {
      return [
        FilledButton.icon(
          onPressed: notifier.reset,
          icon: const Icon(Icons.refresh),
          label: const Text('Reset'),
        ),
      ];
    }
    return [
      FilledButton.icon(
        onPressed: () => notifier.start(_defaultFocusMinutes),
        icon: const Icon(Icons.play_arrow),
        label: const Text('Start'),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              Icons.center_focus_strong_outlined,
              color: theme.colorScheme.primary,
            ),
            const SizedBox(width: 8),
            Text('Focus Mode', style: theme.textTheme.titleMedium),
          ],
        ),
        const SizedBox(height: 16),
        Center(
          child: Text(
            _formatDuration(session.remainingTime),
            style: theme.textTheme.displaySmall,
          ),
        ),
        const SizedBox(height: 12),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(value: session.progress, minHeight: 8),
        ),
        const SizedBox(height: 16),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: _buttons()),
      ],
    );
  }
}
