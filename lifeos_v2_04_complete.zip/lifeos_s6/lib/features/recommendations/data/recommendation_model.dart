/// How urgently a recommendation deserves attention — Sprint V2-04
/// Task 1.
enum RecommendationPriority { low, medium, high }

/// What area of the app a recommendation relates to — drives which
/// icon it's shown with (see `RecommendationsCard`).
enum RecommendationType { focus, tasks, dailyNote, objectives, positive }

/// One suggested action, generated deterministically from existing app
/// data — Sprint V2-04 Task 1. No LLM, no network: see
/// `RecommendationService`'s own doc comment for how these are built.
///
/// No persistence and nothing currently looks a recommendation up by
/// [id] — it exists as a stable per-rule key (useful for widget list
/// keys, and so a future "dismiss this" feature has something to
/// reference) rather than because anything needs it today.
class Recommendation {
  const Recommendation({
    required this.id,
    required this.title,
    required this.description,
    required this.priority,
    required this.recommendationType,
  });

  final String id;
  final String title;
  final String description;
  final RecommendationPriority priority;
  final RecommendationType recommendationType;
}
