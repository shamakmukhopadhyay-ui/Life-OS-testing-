import '../../score/data/daily_score_result.dart';
import '../data/recommendation_model.dart';

/// Everything [RecommendationService.generate] needs to run its rules —
/// plain values only, no Riverpod, no raw `Document`/`Task`/`FocusSession`
/// objects. Same "handed exactly what it needs, nothing more" shape
/// every other service in this project takes (`SearchService`,
/// `FocusService`, ...) — reusing [DailyStatus] (Score feature) rather
/// than re-deriving a "low score" threshold here, so this stays
/// consistent with however `ScoreConfig`'s thresholds are tuned
/// elsewhere, automatically.
class RecommendationInputs {
  const RecommendationInputs({
    required this.remainingTaskCount,
    required this.hasFocusSessionToday,
    required this.dailyNoteHasContent,
    required this.dailyScoreStatus,
  });

  final int remainingTaskCount;
  final bool hasFocusSessionToday;
  final bool dailyNoteHasContent;
  final DailyStatus dailyScoreStatus;
}

typedef _Rule = Recommendation? Function(RecommendationInputs inputs);

/// Generates today's recommendations from existing app data — Sprint
/// V2-04 Task 2.
///
/// Static and dependency-free, same shape as every other service in
/// this project: every method is a pure function of the
/// [RecommendationInputs] handed to it. Rules are a plain list of small
/// functions below, each independent and each free to return null
/// ("doesn't apply") — adding a new rule is adding one function and one
/// list entry, never touching the others. This is what "modular and
/// easy to extend" means concretely here.
///
/// No "everything on track" rule lives here — when no rule applies,
/// [generate] returns an empty list like any other "no matches" result
/// (same as `SearchService.search` returning `[]`). The positive-
/// reinforcement message itself is a Presentation-layer concern
/// (`RecommendationsCard`'s empty state), not a synthesized
/// recommendation — see that file's doc comment.
class RecommendationService {
  RecommendationService._(); // not instantiable

  static final _rules = <_Rule>[
    _remainingTasksRule,
    _dailyScoreRule,
    _focusSessionRule,
    _dailyNoteRule,
  ];

  static const _manyTasksThreshold = 5;

  /// Every applicable rule's recommendation, highest priority first,
  /// capped at 3 (Task 4's "top 3"). Empty when nothing applies.
  static List<Recommendation> generate(RecommendationInputs inputs) {
    final active = [
      for (final rule in _rules) rule(inputs),
    ].whereType<Recommendation>().toList()
      ..sort((a, b) => b.priority.index.compareTo(a.priority.index));
    return active.take(3).toList();
  }

  static Recommendation? _remainingTasksRule(RecommendationInputs inputs) {
    if (inputs.remainingTaskCount < _manyTasksThreshold) return null;
    return Recommendation(
      id: 'remaining-tasks',
      title: 'Clear some tasks',
      description:
          'You have ${inputs.remainingTaskCount} tasks remaining today.',
      priority: RecommendationPriority.high,
      recommendationType: RecommendationType.tasks,
    );
  }

  static Recommendation? _dailyScoreRule(RecommendationInputs inputs) {
    if (inputs.dailyScoreStatus != DailyStatus.needsImprovement) return null;
    return const Recommendation(
      id: 'low-daily-score',
      title: "Boost today's score",
      description: 'Finishing an objective or two would help.',
      priority: RecommendationPriority.high,
      recommendationType: RecommendationType.objectives,
    );
  }

  static Recommendation? _focusSessionRule(RecommendationInputs inputs) {
    if (inputs.hasFocusSessionToday) return null;
    return const Recommendation(
      id: 'start-focus-session',
      title: 'Start a focus session',
      description: "You haven't started a focus session today.",
      priority: RecommendationPriority.medium,
      recommendationType: RecommendationType.focus,
    );
  }

  static Recommendation? _dailyNoteRule(RecommendationInputs inputs) {
    if (inputs.dailyNoteHasContent) return null;
    return const Recommendation(
      id: 'write-daily-note',
      title: "Write today's note",
      description: "You haven't written in today's daily note yet.",
      priority: RecommendationPriority.medium,
      recommendationType: RecommendationType.dailyNote,
    );
  }
}
