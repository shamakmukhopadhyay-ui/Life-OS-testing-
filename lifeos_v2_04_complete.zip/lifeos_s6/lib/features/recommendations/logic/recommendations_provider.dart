import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/utils/date_time_helpers.dart';
import '../../documents/logic/daily_note_service.dart';
import '../../documents/logic/document_provider.dart';
import '../../focus/logic/focus_provider.dart';
import '../../score/logic/score_provider.dart';
import '../../tasks/logic/tasks_provider.dart';
import 'recommendation_service.dart';

/// Whether [content] has any real writing beyond its YAML frontmatter
/// block (if any). A freshly auto-created daily note (see
/// `DailyNoteService.getOrCreate`) has frontmatter but no body — this
/// is what distinguishes "note exists but is still blank" from "note
/// has something written in it." Deliberately a small, local heuristic
/// rather than reusing anything from the Documents/Markdown system —
/// this sprint's regression rules leave those untouched, and this
/// check is generic enough (strip a leading `---`-delimited block,
/// see if anything non-blank remains) not to need them.
bool _hasBodyContent(String content) {
  var body = content;
  if (body.startsWith('---')) {
    final closingIndex = body.indexOf('\n---', 3);
    if (closingIndex != -1) {
      final afterDelimiter = body.indexOf('\n', closingIndex + 1);
      body = afterDelimiter == -1 ? '' : body.substring(afterDelimiter + 1);
    }
  }
  return body.trim().isNotEmpty;
}

/// Exposes today's recommendations — Sprint V2-04 Task 3.
///
/// Purely a data-gathering call-through: reads the existing providers
/// this feature draws from, extracts the plain values
/// [RecommendationService] needs, and hands them over. Every
/// *interpretation* of those values (what counts as "many" tasks,
/// "low" score, etc.) happens inside the service, not here — this
/// provider makes no such decisions itself, per Task 3's "no business
/// logic."
///
/// Deliberately calls [DailyNoteService.get] (read-only) rather than
/// watching `dailyNoteProvider` (which auto-creates a blank note if
/// missing, since Sprint 23) — recommending "write today's note"
/// shouldn't itself silently create one just because Home was opened.
final recommendationsProvider = FutureProvider((ref) async {
  final tasks = ref.watch(tasksProvider).valueOrNull ?? [];
  final remainingTaskCount = tasks.where((t) => !t.isCompleted).length;

  final focusSession = ref.watch(focusProvider).valueOrNull;
  final hasFocusSessionToday = focusSession != null &&
      !focusSession.isIdle &&
      focusSession.startTime != null &&
      isSameDay(focusSession.startTime!, DateTime.now());

  final repo = ref.read(documentRepositoryProvider);
  final dailyNote = await DailyNoteService.get(repo, DateTime.now());
  final dailyNoteHasContent =
      dailyNote != null && _hasBodyContent(dailyNote.content);

  final dailyScore = ref.watch(dailyScoreProvider);

  final inputs = RecommendationInputs(
    remainingTaskCount: remainingTaskCount,
    hasFocusSessionToday: hasFocusSessionToday,
    dailyNoteHasContent: dailyNoteHasContent,
    dailyScoreStatus: dailyScore.status,
  );
  return RecommendationService.generate(inputs);
});
