import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/widgets/empty_state.dart';
import '../../data/recommendation_model.dart';
import '../../logic/recommendations_provider.dart';

/// Replaces the "AI Suggestions" placeholder on Home — Sprint V2-04
/// Task 4.
///
/// "AI" here means deterministic, offline, rule-based suggestions — see
/// `RecommendationService`'s doc comment. No network, no LLM; every
/// recommendation traces back to a plain rule over existing app data.
/// When nothing needs attention, [recommendationsProvider] returns an
/// empty list and this card shows a positive-reinforcement [EmptyState]
/// rather than the service synthesizing a fake "everything's fine"
/// recommendation object.
class RecommendationsCard extends ConsumerWidget {
  const RecommendationsCard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final recommendationsAsync = ref.watch(recommendationsProvider);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.auto_awesome_outlined,
                  color: theme.colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Text('AI Suggestions', style: theme.textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: 12),
            recommendationsAsync.when(
              loading: () => const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Center(child: CircularProgressIndicator()),
              ),
              error: (error, _) => Text(
                'Could not load suggestions',
                style: theme.textTheme.bodyMedium,
              ),
              data: (recommendations) {
                if (recommendations.isEmpty) {
                  return const EmptyState(
                    icon: Icons.celebration_outlined,
                    title: "You're on track",
                    message: 'Nothing urgent right now — nice work today.',
                  );
                }
                return Column(
                  children: [
                    for (final recommendation in recommendations) ...[
                      _RecommendationTile(recommendation: recommendation),
                      const SizedBox(height: 4),
                    ],
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _RecommendationTile extends StatelessWidget {
  const _RecommendationTile({required this.recommendation});

  final Recommendation recommendation;

  IconData get _typeIcon => switch (recommendation.recommendationType) {
        RecommendationType.focus => Icons.center_focus_strong_outlined,
        RecommendationType.tasks => Icons.check_circle_outline,
        RecommendationType.dailyNote => Icons.description_outlined,
        RecommendationType.objectives => Icons.flag_outlined,
        RecommendationType.positive => Icons.celebration_outlined,
      };

  Color _priorityColor(ThemeData theme) => switch (recommendation.priority) {
        RecommendationPriority.high => theme.colorScheme.error,
        RecommendationPriority.medium => theme.colorScheme.primary,
        RecommendationPriority.low => theme.colorScheme.outline,
      };

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(_typeIcon, color: theme.colorScheme.onSurfaceVariant),
      title: Text(recommendation.title),
      subtitle: Text(recommendation.description),
      trailing: Container(
        width: 10,
        height: 10,
        margin: const EdgeInsets.only(top: 4),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _priorityColor(theme),
        ),
      ),
    );
  }
}
