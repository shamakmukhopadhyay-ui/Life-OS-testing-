import 'package:flutter/material.dart';

/// Dashboard card giving a quick glance at the current week, with today
/// highlighted.
///
/// Purely visual: the days shown are computed from `DateTime.now()` (date
/// math, not business logic), and tapping a day does nothing yet — a real
/// Calendar screen/feature is future scope, not part of Phase 2.
class CalendarPreviewCard extends StatelessWidget {
  const CalendarPreviewCard({super.key});

  static const List<String> _dayLabels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final DateTime today = DateTime.now();
    final DateTime startOfWeek =
        today.subtract(Duration(days: today.weekday - 1));

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('This Week', style: theme.textTheme.titleMedium),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: List.generate(7, (i) {
                final day = startOfWeek.add(Duration(days: i));
                final bool isToday = day.day == today.day &&
                    day.month == today.month &&
                    day.year == today.year;
                return Column(
                  children: [
                    Text(_dayLabels[i], style: theme.textTheme.labelSmall),
                    const SizedBox(height: 6),
                    CircleAvatar(
                      radius: 16,
                      backgroundColor: isToday
                          ? theme.colorScheme.primary
                          : theme.colorScheme.surfaceContainerHighest,
                      child: Text(
                        '${day.day}',
                        style: TextStyle(
                          color: isToday
                              ? theme.colorScheme.onPrimary
                              : theme.colorScheme.onSurfaceVariant,
                          fontWeight:
                              isToday ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    ),
                  ],
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}
