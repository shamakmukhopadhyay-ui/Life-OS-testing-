import 'package:flutter/material.dart';

import '../../../features/score/data/daily_score_result.dart';

/// Dashboard card displaying today's overall score as a ring plus a
/// breakdown of points earned, remaining, and a status label.
///
/// Accepts a [DailyScoreResult] produced by [dailyScoreProvider] — it
/// contains no calculation logic itself. The scoring algorithm lives
/// entirely in [ScoreService]; this widget is purely presentational.
class DailyProgressCard extends StatelessWidget {
  const DailyProgressCard({
    super.key,
    required this.score,
  });

  final DailyScoreResult score;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final statusColor = _statusColor(context, score.status);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            // ── Circular progress ring ──────────────────────────────
            SizedBox(
              width: 64,
              height: 64,
              child: Stack(
                fit: StackFit.expand,
                alignment: Alignment.center,
                children: [
                  CircularProgressIndicator(
                    value: score.scoreValue,
                    strokeWidth: 6,
                    color: statusColor,
                    backgroundColor:
                        theme.colorScheme.surfaceContainerHighest,
                  ),
                  Text(
                    '${score.scorePercent.round()}%',
                    style: theme.textTheme.labelMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 16),
            // ── Text column ─────────────────────────────────────────
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title row + status chip
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Daily Progress',
                          style: theme.textTheme.titleMedium,
                        ),
                      ),
                      _StatusChip(
                        label: score.statusLabel,
                        color: statusColor,
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  // Points earned
                  Text(
                    '${score.earnedPoints} pts earned',
                    style: theme.textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 2),
                  // Points remaining
                  Text(
                    score.remainingPoints > 0
                        ? '${score.remainingPoints} pts remaining'
                        : 'All points earned!',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: score.remainingPoints > 0
                          ? theme.colorScheme.outline
                          : Colors.green,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Maps [DailyStatus] to a colour used by both the ring and the chip.
  static Color _statusColor(BuildContext context, DailyStatus status) {
    return switch (status) {
      DailyStatus.excellent => Colors.green,
      DailyStatus.good => Colors.amber.shade700,
      DailyStatus.fair => Colors.orange,
      DailyStatus.needsImprovement =>
        Theme.of(context).colorScheme.error,
    };
  }
}

/// Small coloured label chip for the status (Excellent / Good / …).
/// Private to this file — only [DailyProgressCard] uses it.
class _StatusChip extends StatelessWidget {
  const _StatusChip({required this.label, required this.color});

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Text(
        label,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: color,
              fontWeight: FontWeight.w600,
            ),
      ),
    );
  }
}
