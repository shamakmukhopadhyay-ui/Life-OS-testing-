import 'package:flutter/material.dart';

import '../../../core/utils/date_time_helpers.dart';

/// Shows today's date, a time-of-day greeting, and a motivational
/// subtitle at the top of the dashboard. Feature-specific to Home (not
/// moved to `core/widgets` because no other feature currently needs
/// this exact combination) but reuses the shared `core/utils`
/// formatting.
///
/// Purely presentational: reads the current time once at build, holds
/// no state, touches no database.
///
/// The subtitle (V2-02 Task 1) is a static placeholder line, matching
/// the task's own wording — a rotating/dynamic quote system wasn't
/// asked for, so this doesn't build one.
class GreetingHeader extends StatelessWidget {
  const GreetingHeader({super.key});

  static const _motivationalSubtitle = "Let's make today count.";

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          formatFullDate(now),
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.outline,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          greetingForHour(now.hour),
          style: theme.textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          _motivationalSubtitle,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.outline,
          ),
        ),
      ],
    );
  }
}
