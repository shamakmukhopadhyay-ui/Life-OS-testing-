import 'package:flutter/material.dart';

/// The app's bottom navigation, using Material 3's [NavigationBar] (the
/// current MD3 replacement for the older BottomNavigationBar widget).
///
/// LifeOS V2-01: all four destinations now switch real content (an
/// `IndexedStack` in home_screen.dart) rather than three of them being
/// purely visual. "Real" here means "a distinct screen renders," not
/// "the screen has working features yet" — Today, Learn, and Library
/// are this sprint's placeholder screens; only Home's content is the
/// pre-existing, fully working dashboard.
class HomeBottomNavBar extends StatelessWidget {
  const HomeBottomNavBar({
    super.key,
    required this.selectedIndex,
    required this.onDestinationSelected,
  });

  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;

  @override
  Widget build(BuildContext context) {
    return NavigationBar(
      selectedIndex: selectedIndex,
      onDestinationSelected: onDestinationSelected,
      destinations: const [
        NavigationDestination(
          icon: Icon(Icons.home_outlined),
          selectedIcon: Icon(Icons.home),
          label: 'Home',
        ),
        NavigationDestination(
          icon: Icon(Icons.today_outlined),
          selectedIcon: Icon(Icons.today),
          label: 'Today',
        ),
        NavigationDestination(
          icon: Icon(Icons.school_outlined),
          selectedIcon: Icon(Icons.school),
          label: 'Learn',
        ),
        NavigationDestination(
          icon: Icon(Icons.local_library_outlined),
          selectedIcon: Icon(Icons.local_library),
          label: 'Library',
        ),
      ],
    );
  }
}
