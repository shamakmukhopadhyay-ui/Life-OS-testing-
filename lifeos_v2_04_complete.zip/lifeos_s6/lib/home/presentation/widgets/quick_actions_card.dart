import 'package:flutter/material.dart';

/// Three action buttons — Sprint 22 V2-02 Task 6.
///
/// Pure Presentation: takes callbacks, does not read a provider or
/// call a service itself ("UI contains no business logic") — what
/// each button actually does lives in `home_screen.dart`, where the
/// providers/navigation context already are.
class QuickActionsCard extends StatelessWidget {
  const QuickActionsCard({
    super.key,
    required this.onNewTask,
    required this.onNewNote,
    required this.onTodaysNote,
  });

  final VoidCallback onNewTask;
  final VoidCallback onNewNote;
  final VoidCallback onTodaysNote;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.bolt_outlined, color: theme.colorScheme.primary),
                const SizedBox(width: 8),
                Text('Quick Actions', style: theme.textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton.icon(
                  onPressed: onNewTask,
                  icon: const Icon(Icons.add_task),
                  label: const Text('New Task'),
                ),
                OutlinedButton.icon(
                  onPressed: onNewNote,
                  icon: const Icon(Icons.note_add_outlined),
                  label: const Text('New Note'),
                ),
                OutlinedButton.icon(
                  onPressed: onTodaysNote,
                  icon: const Icon(Icons.today_outlined),
                  label: const Text("Today's Note"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
