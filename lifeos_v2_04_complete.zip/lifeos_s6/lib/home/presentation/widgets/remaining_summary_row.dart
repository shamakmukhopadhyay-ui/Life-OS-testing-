import 'package:flutter/material.dart';

/// "X objectives · Y tasks remaining" — Sprint 22 V2-02 Task 2's
/// remaining-objectives/remaining-tasks counts.
///
/// A separate, small widget rather than an addition to
/// `DailyProgressCard` — that card is already a complete, working
/// piece (score, progress ring, points chip) and Task 2's counts are a
/// distinct, simpler concern that doesn't need to live inside it.
/// Takes plain counts, not the lists themselves or any provider — the
/// caller already has `activeObjectives`/incomplete tasks in hand for
/// other sections, so this avoids "no duplicated calculations" (Task
/// 2) by construction: there is nothing here to duplicate, since it
/// does no calculation of its own.
class RemainingSummaryRow extends StatelessWidget {
  const RemainingSummaryRow({
    super.key,
    required this.remainingObjectives,
    required this.remainingTasks,
  });

  final int remainingObjectives;
  final int remainingTasks;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final style = theme.textTheme.bodyMedium?.copyWith(
      color: theme.colorScheme.outline,
    );

    return Row(
      children: [
        Icon(Icons.flag_outlined, size: 16, color: theme.colorScheme.outline),
        const SizedBox(width: 4),
        Text('$remainingObjectives objectives', style: style),
        const SizedBox(width: 16),
        Icon(
          Icons.check_box_outlined,
          size: 16,
          color: theme.colorScheme.outline,
        ),
        const SizedBox(width: 4),
        Text('$remainingTasks tasks remaining', style: style),
      ],
    );
  }
}
