import 'package:flutter/material.dart';

import '../../core/widgets/empty_state.dart';

/// Settings placeholder — LifeOS V2-01 Task 7.
///
/// Reachable from Home's AppBar (see home_screen.dart), not from bottom
/// navigation — Settings was explicitly removed from the tab bar this
/// sprint. Registered at the `/settings` route.
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: const EmptyState(
        icon: Icons.settings_outlined,
        title: 'Settings coming soon',
        message: 'App preferences and vault configuration will live here.',
      ),
    );
  }
}
