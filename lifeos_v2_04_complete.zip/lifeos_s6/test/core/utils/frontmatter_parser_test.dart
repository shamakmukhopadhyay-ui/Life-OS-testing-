import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/core/utils/frontmatter_parser.dart';

void main() {
  group('parseFrontmatter', () {
    test('returns empty map when there is no frontmatter block', () {
      final result = parseFrontmatter('# Just a heading\n\nSome body text.');
      expect(result, isEmpty);
    });

    test('returns empty map for completely empty content', () {
      expect(parseFrontmatter(''), isEmpty);
    });

    test('parses a simple key/value block', () {
      const content = '---\ntitle: My Note\ndate: 2026-07-11\n---\nBody';
      final result = parseFrontmatter(content);
      expect(result['title'], 'My Note');
      // Some YAML implementations resolve an unquoted YYYY-MM-DD scalar to
      // a DateTime rather than a String; either way its string form must
      // start with the date, so this holds regardless of which it is.
      expect(result['date'].toString(), startsWith('2026-07-11'));
    });

    test('preserves unknown/arbitrary keys untouched', () {
      const content = '---\n'
          'title: Foo\n'
          'custom_plugin_field: some-value\n'
          'aliases: [Bar, Baz]\n'
          '---\n'
          'Body';
      final result = parseFrontmatter(content);
      expect(result['custom_plugin_field'], 'some-value');
      expect(result['aliases'], ['Bar', 'Baz']);
    });

    test('unwraps nested lists to plain List, not YamlList', () {
      const content = '---\ntags: [daily, work]\n---\nBody';
      final result = parseFrontmatter(content);
      expect(result['tags'], isA<List>());
      expect(result['tags'], ['daily', 'work']);
    });

    test('unwraps nested maps to plain Map, not YamlMap', () {
      const content = '---\nmeta:\n  nested: value\n---\nBody';
      final result = parseFrontmatter(content);
      expect(result['meta'], isA<Map>());
      expect((result['meta'] as Map)['nested'], 'value');
    });

    test('returns empty map when there is no closing delimiter', () {
      const content = '---\ntitle: Unterminated\nBody with no closing dashes';
      expect(parseFrontmatter(content), isEmpty);
    });

    test('returns empty map for an empty frontmatter block', () {
      const content = '---\n---\nBody';
      expect(parseFrontmatter(content), isEmpty);
    });

    test('degrades to empty map on malformed YAML rather than throwing', () {
      const content = '---\ntitle: "unterminated quote\n---\nBody';
      expect(() => parseFrontmatter(content), returnsNormally);
      expect(parseFrontmatter(content), isEmpty);
    });

    test('handles CRLF line endings around the delimiters', () {
      const content = '---\r\ntitle: CRLF Note\r\n---\r\n\r\nBody';
      final result = parseFrontmatter(content);
      expect(result['title'].toString().trim(), 'CRLF Note');
    });

    test('strips a leading UTF-8 BOM before detecting frontmatter', () {
      // Sprint 19 vault-compatibility audit: a file saved with a BOM
      // (some Windows tools do this) must not silently lose its
      // frontmatter just because of that one extra leading character.
      const content = '\uFEFF---\ntitle: BOM Note\n---\nBody';
      final result = parseFrontmatter(content);
      expect(result['title'], 'BOM Note');
    });

    test('behaves identically with or without a BOM for the same '
        'otherwise-identical content', () {
      const withoutBom = '---\ntitle: Same Note\ntags: [a, b]\n---\nBody';
      const withBom = '\uFEFF$withoutBom';
      expect(parseFrontmatter(withBom), parseFrontmatter(withoutBom));
    });

    test('does not treat a mid-body "---" as frontmatter when content '
        "doesn't start with one", () {
      const content = 'Some intro\n---\ntitle: Not Frontmatter\n---\nBody';
      expect(parseFrontmatter(content), isEmpty);
    });
  });

  group('tagsFromFrontmatter', () {
    test('reads a YAML list of tags', () {
      final tags = tagsFromFrontmatter({'tags': ['daily', 'work']});
      expect(tags, ['daily', 'work']);
    });

    test('wraps a single scalar tag into a one-element list', () {
      final tags = tagsFromFrontmatter({'tags': 'daily'});
      expect(tags, ['daily']);
    });

    test('returns an empty list when tags key is absent', () {
      expect(tagsFromFrontmatter({'title': 'No tags here'}), isEmpty);
    });

    test('returns an empty list for an unexpected tags type', () {
      expect(tagsFromFrontmatter({'tags': 42}), isEmpty);
    });

    test('returns an empty list for a blank scalar tag', () {
      expect(tagsFromFrontmatter({'tags': '   '}), isEmpty);
    });
  });
}
