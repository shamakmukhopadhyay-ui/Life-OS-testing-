import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/features/documents/data/document_metadata_model.dart';

void main() {
  final fallbackCreated = DateTime(2025, 1, 1);
  final fallbackModified = DateTime(2025, 6, 15);

  DocumentMetadata parse(Map<String, dynamic> frontmatter) {
    return DocumentMetadata.fromFrontmatter(
      frontmatter,
      fallbackTitle: 'Fallback Title',
      fallbackCreated: fallbackCreated,
      fallbackModified: fallbackModified,
    );
  }

  group('DocumentMetadata.fromFrontmatter — empty/missing frontmatter', () {
    test('uses every fallback when frontmatter is empty', () {
      final meta = parse(const {});

      expect(meta.title, 'Fallback Title');
      expect(meta.type, isNull);
      expect(meta.tags, isEmpty);
      expect(meta.favorite, isFalse);
      expect(meta.pinned, isFalse);
      expect(meta.created, fallbackCreated);
      expect(meta.modified, fallbackModified);
      expect(meta.custom, isEmpty);
    });
  });

  group('DocumentMetadata.fromFrontmatter — title', () {
    test('uses frontmatter title when present', () {
      final meta = parse({'title': 'My Note'});
      expect(meta.title, 'My Note');
    });

    test('falls back when title is blank', () {
      final meta = parse({'title': '   '});
      expect(meta.title, 'Fallback Title');
    });

    test('falls back when title is the wrong type', () {
      final meta = parse({'title': 42});
      expect(meta.title, 'Fallback Title');
    });
  });

  group('DocumentMetadata.fromFrontmatter — type', () {
    test('reads a string type', () {
      expect(parse({'type': 'journal'}).type, 'journal');
    });

    test('is null when absent', () {
      expect(parse(const {}).type, isNull);
    });

    test('is null when blank or the wrong type', () {
      expect(parse({'type': '  '}).type, isNull);
      expect(parse({'type': 7}).type, isNull);
    });
  });

  group('DocumentMetadata.fromFrontmatter — favorite/pinned', () {
    test('reads true booleans', () {
      final meta = parse({'favorite': true, 'pinned': true});
      expect(meta.favorite, isTrue);
      expect(meta.pinned, isTrue);
    });

    test('reads false booleans', () {
      final meta = parse({'favorite': false, 'pinned': false});
      expect(meta.favorite, isFalse);
      expect(meta.pinned, isFalse);
    });

    test('defaults to false for a quoted-string boolean', () {
      // frontmatter's `favorite: "true"` parses to the Dart String
      // "true", not a bool — documented as "wrong type degrades to
      // false" rather than doing string coercion.
      final meta = parse({'favorite': 'true', 'pinned': 'yes'});
      expect(meta.favorite, isFalse);
      expect(meta.pinned, isFalse);
    });

    test('defaults to false when absent', () {
      final meta = parse(const {});
      expect(meta.favorite, isFalse);
      expect(meta.pinned, isFalse);
    });
  });

  group('DocumentMetadata.fromFrontmatter — created/modified', () {
    test('uses a DateTime value directly (as loadYaml would produce)',
        () {
      final created = DateTime(2026, 1, 15);
      final modified = DateTime(2026, 2, 20);
      final meta = parse({'created': created, 'modified': modified});
      expect(meta.created, created);
      expect(meta.modified, modified);
    });

    test('parses a string date', () {
      final meta = parse({
        'created': '2026-01-15',
        'modified': '2026-02-20',
      });
      expect(meta.created, DateTime.parse('2026-01-15'));
      expect(meta.modified, DateTime.parse('2026-02-20'));
    });

    test('falls back on an unparsable string', () {
      final meta = parse({'created': 'not a date'});
      expect(meta.created, fallbackCreated);
    });

    test('falls back on the wrong type', () {
      final meta = parse({'created': 12345});
      expect(meta.created, fallbackCreated);
    });

    test('falls back when absent', () {
      final meta = parse(const {});
      expect(meta.created, fallbackCreated);
      expect(meta.modified, fallbackModified);
    });
  });

  group('DocumentMetadata.fromFrontmatter — tags', () {
    test('reads a list of tags', () {
      final meta = parse({'tags': ['work', 'urgent']});
      expect(meta.tags, ['work', 'urgent']);
    });

    test('reads a single scalar tag', () {
      final meta = parse({'tags': 'solo'});
      expect(meta.tags, ['solo']);
    });

    test('is empty when absent', () {
      expect(parse(const {}).tags, isEmpty);
    });
  });

  group('DocumentMetadata.fromFrontmatter — custom properties', () {
    test('captures unknown keys', () {
      final meta = parse({
        'title': 'My Note',
        'mood': 'happy',
        'project': 'LifeOS',
        'rating': 5,
      });
      expect(meta.custom, {'mood': 'happy', 'project': 'LifeOS', 'rating': 5});
    });

    test('never leaks a known key into custom', () {
      final meta = parse({
        'title': 'x',
        'type': 'note',
        'tags': ['a'],
        'favorite': true,
        'pinned': true,
        'created': '2026-01-01',
        'modified': '2026-01-02',
        'mood': 'calm',
      });
      expect(meta.custom.keys, ['mood']);
    });

    test('is empty when every key is a known field', () {
      final meta = parse({'title': 'x', 'favorite': true});
      expect(meta.custom, isEmpty);
    });
  });
}
