import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:lifeos/features/documents/data/document_model.dart';
import 'package:lifeos/features/documents/data/internal_document_repository.dart';
import 'package:lifeos/features/documents/data/vault_model.dart';

// ── Schema helper ─────────────────────────────────────────────────────────────

/// Creates only the `documents` table — the subset needed to test the repo.
Future<void> _createSchema(Database db) async {
  await db.execute('''
    CREATE TABLE documents (
      path        TEXT    PRIMARY KEY NOT NULL,
      vault_id    TEXT    NOT NULL,
      title       TEXT    NOT NULL DEFAULT '',
      content     TEXT    NOT NULL DEFAULT '',
      tags        TEXT    NOT NULL DEFAULT '[]',
      frontmatter TEXT    NOT NULL DEFAULT '{}',
      metadata    TEXT    NOT NULL DEFAULT '{}',
      created_at  INTEGER NOT NULL,
      updated_at  INTEGER NOT NULL
    )
  ''');
}

// ── Test data ─────────────────────────────────────────────────────────────────

Document _makeDoc({
  String path = 'daily/2025-07-11.md',
  String title = 'Test Note',
  String content = '# Hello',
  String vaultId = 'internal',
  List<String> tags = const ['daily'],
}) {
  final now = DateTime(2025, 7, 11);
  return Document(
    path: path,
    vaultId: vaultId,
    title: title,
    content: content,
    tags: tags,
    createdAt: now,
    updatedAt: now,
  );
}

// ── Tests ─────────────────────────────────────────────────────────────────────

void main() {
  setUpAll(() {
    // Initialise sqflite to use the FFI implementation on the host runner
    // (macOS / Linux / Windows CI) rather than the mobile plugin.
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  late Database db;
  late InternalDocumentRepository repo;
  const vault = Vault.defaultInternal;

  setUp(() async {
    db = await openDatabase(
      inMemoryDatabasePath,
      version: 1,
      onCreate: (db, _) => _createSchema(db),
    );
    repo = InternalDocumentRepository(vault: vault, db: db);
  });

  tearDown(() => db.close());

  group('InternalDocumentRepository — CRUD', () {
    test('getByPath returns null for missing document', () async {
      final result = await repo.getByPath('missing/path.md');
      expect(result, isNull);
    });

    test('save then getByPath round-trips all fields', () async {
      final doc = _makeDoc();
      await repo.save(doc);

      final loaded = await repo.getByPath(doc.path);
      expect(loaded, isNotNull);
      expect(loaded!.path, doc.path);
      expect(loaded.title, doc.title);
      expect(loaded.content, doc.content);
      expect(loaded.tags, doc.tags);
      expect(loaded.vaultId, vault.id);
    });

    test('save inserts a new document', () async {
      final doc = _makeDoc();
      await repo.save(doc);

      expect(await repo.exists(doc.path), isTrue);
    });

    test('save updates an existing document', () async {
      final doc = _makeDoc();
      await repo.save(doc);

      final updated = doc.copyWith(content: '# Updated content');
      await repo.save(updated);

      final loaded = await repo.getByPath(doc.path);
      expect(loaded!.content, '# Updated content');
    });

    test('save preserves createdAt on update', () async {
      final doc = _makeDoc();
      final saved = await repo.save(doc);
      final createdAt = saved.createdAt;

      // Small delay to make updatedAt differ if it were reset.
      await Future<void>.delayed(const Duration(milliseconds: 10));

      final updated = doc.copyWith(content: '# Changed');
      final reSaved = await repo.save(updated);

      final loaded = await repo.getByPath(doc.path);
      expect(loaded!.createdAt.millisecondsSinceEpoch,
          createdAt.millisecondsSinceEpoch);
      // updatedAt should have advanced
      expect(reSaved.updatedAt.millisecondsSinceEpoch,
          greaterThanOrEqualTo(createdAt.millisecondsSinceEpoch));
    });

    test('delete removes the document', () async {
      final doc = _makeDoc();
      await repo.save(doc);
      await repo.delete(doc.path);

      expect(await repo.exists(doc.path), isFalse);
      expect(await repo.getByPath(doc.path), isNull);
    });

    test('getAll returns all documents for this vault', () async {
      await repo.save(_makeDoc(path: 'a.md'));
      await repo.save(_makeDoc(path: 'b.md'));
      await repo.save(_makeDoc(path: 'c.md'));

      final all = await repo.getAll();
      expect(all.length, 3);
    });

    test('getAll is scoped to vault — does not return other vaults', () async {
      await repo.save(_makeDoc(path: 'mine.md', vaultId: vault.id));

      // Insert a row from a different vault directly.
      final now = DateTime.now().millisecondsSinceEpoch;
      await db.insert('documents', {
        'path': 'other.md',
        'vault_id': 'obsidian-vault',
        'title': 'Other',
        'content': '',
        'tags': '[]',
        'frontmatter': '{}',
        'metadata': '{}',
        'created_at': now,
        'updated_at': now,
      });

      final all = await repo.getAll();
      expect(all.length, 1);
      expect(all.first.path, 'mine.md');
    });

    test('exists returns true for saved, false for missing', () async {
      final doc = _makeDoc();
      expect(await repo.exists(doc.path), isFalse);
      await repo.save(doc);
      expect(await repo.exists(doc.path), isTrue);
    });
  });

  group('InternalDocumentRepository — tag and search', () {
    test('getByTag returns only matching documents', () async {
      await repo.save(_makeDoc(path: 'a.md', tags: ['daily', 'work']));
      await repo.save(_makeDoc(path: 'b.md', tags: ['personal']));

      final results = await repo.getByTag('work');
      expect(results.length, 1);
      expect(results.first.path, 'a.md');
    });

    test('search matches title substring', () async {
      await repo.save(_makeDoc(path: 'a.md', title: 'Meeting Notes'));
      await repo.save(_makeDoc(path: 'b.md', title: 'Shopping List'));

      final results = await repo.search('Meeting');
      expect(results.length, 1);
      expect(results.first.title, 'Meeting Notes');
    });

    test('search matches content substring', () async {
      await repo.save(_makeDoc(path: 'a.md', content: '# Project Alpha plan'));
      await repo.save(_makeDoc(path: 'b.md', content: '# Groceries'));

      final results = await repo.search('Alpha');
      expect(results.length, 1);
    });
  });
}
