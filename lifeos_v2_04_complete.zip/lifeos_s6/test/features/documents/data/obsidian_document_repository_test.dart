import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:path/path.dart' as p;

import 'package:lifeos/core/filesystem/internal_filesystem.dart';
import 'package:lifeos/features/documents/data/document_model.dart';
import 'package:lifeos/features/documents/data/obsidian_document_repository.dart';
import 'package:lifeos/features/documents/data/vault_model.dart';
import 'package:lifeos/features/documents/logic/daily_note_service.dart';

// ── Test data ─────────────────────────────────────────────────────────────────

Document _makeDoc({
  required String path,
  String title = 'Test Note',
  String content = '# Hello',
  required String vaultId,
}) {
  final now = DateTime(2026, 7, 25);
  return Document(
    path: path,
    vaultId: vaultId,
    title: title,
    content: content,
    createdAt: now,
    updatedAt: now,
  );
}

// ── Tests ─────────────────────────────────────────────────────────────────────
//
// These run against a real temp directory on disk via InternalFileSystem —
// the same dart:io-backed FileSystemService a real Obsidian vault root would
// use (see internal_filesystem.dart's own doc comment). A fake/in-memory
// filesystem would trivially "preserve" bytes and mtimes with nothing to
// actually preserve; the fidelity requirements in this sprint (byte-exact
// round trips, unnecessary-write avoidance) only mean something tested
// against real file I/O.

void main() {
  late Directory tempDir;
  late String vaultRoot;
  late ObsidianDocumentRepository repo;
  // The repository never reads `vault.rootPath` directly — all path
  // resolution happens through `fileSystem`, which setUp() below points
  // at the real per-test temp directory. This value is purely descriptive.
  const vault = Vault(
    id: 'test-obsidian-vault',
    name: 'Test Vault',
    type: VaultType.obsidian,
    rootPath: '/placeholder',
    capabilities: {
      VaultCapability.read,
      VaultCapability.write,
    },
  );

  setUp(() {
    tempDir = Directory.systemTemp.createTempSync('lifeos_obsidian_test_');
    vaultRoot = tempDir.path;
    repo = ObsidianDocumentRepository(
      vault: vault,
      fileSystem: InternalFileSystem(vaultRoot),
    );
  });

  tearDown(() {
    if (tempDir.existsSync()) tempDir.deleteSync(recursive: true);
  });

  group('ObsidianDocumentRepository — CRUD', () {
    test('getByPath returns null for a missing document', () async {
      final result = await repo.getByPath('missing/path.md');
      expect(result, isNull);
    });

    test('exists returns false, then true after save', () async {
      expect(await repo.exists('a.md'), isFalse);
      await repo.save(_makeDoc(path: 'a.md', vaultId: vault.id));
      expect(await repo.exists('a.md'), isTrue);
    });

    test('save writes a real UTF-8 .md file with no BOM', () async {
      const content = '---\ntitle: New Note\ntags: [test]\n---\n\n# Hello\n';
      await repo.save(_makeDoc(path: 'new_note.md', content: content, vaultId: vault.id));

      final file = File(p.join(vaultRoot, 'new_note.md'));
      expect(await file.exists(), isTrue);

      final bytes = await file.readAsBytes();
      final hasBom = bytes.length >= 3 &&
          bytes[0] == 0xEF &&
          bytes[1] == 0xBB &&
          bytes[2] == 0xBF;
      expect(hasBom, isFalse);
      expect(await file.readAsString(), content); // byte-identical
    });

    test('save then getByPath round-trips content exactly', () async {
      const content = '# Body only, no frontmatter\n\nSome text.';
      await repo.save(_makeDoc(path: 'plain.md', content: content, vaultId: vault.id));

      final loaded = await repo.getByPath('plain.md');
      expect(loaded, isNotNull);
      expect(loaded!.content, content);
    });

    test('save creates parent directories for a nested new path', () async {
      await repo.save(_makeDoc(path: 'Projects/Alpha/notes.md', vaultId: vault.id));
      expect(await File(p.join(vaultRoot, 'Projects', 'Alpha', 'notes.md')).exists(), isTrue);
    });

    test('save updates existing content on disk', () async {
      await repo.save(_makeDoc(path: 'edit.md', content: '# v1', vaultId: vault.id));
      final saved = await repo.save(_makeDoc(path: 'edit.md', content: '# v2', vaultId: vault.id));

      expect(saved.content, '# v2');
      final onDisk = await File(p.join(vaultRoot, 'edit.md')).readAsString();
      expect(onDisk, '# v2');
    });

    test('delete removes an existing file', () async {
      await repo.save(_makeDoc(path: 'to_delete.md', vaultId: vault.id));
      await repo.delete('to_delete.md');
      expect(await repo.exists('to_delete.md'), isFalse);
    });

    test('delete is idempotent for a file that does not exist', () async {
      await expectLater(repo.delete('never_existed.md'), completes);
    });

    test('search is explicitly deferred this sprint', () {
      expect(() => repo.search('anything'), throwsUnimplementedError);
    });

    test('getByTag is explicitly deferred this sprint', () {
      expect(() => repo.getByTag('daily'), throwsUnimplementedError);
    });
  });

  group('ObsidianDocumentRepository — unnecessary-write avoidance', () {
    test('does not touch the file on disk when content is unchanged', () async {
      final doc = await repo.save(
        _makeDoc(path: 'stable.md', content: '# Same', vaultId: vault.id),
      );
      final file = File(p.join(vaultRoot, 'stable.md'));
      final mtimeBefore = file.statSync().modified;

      await Future<void>.delayed(const Duration(milliseconds: 30));
      await repo.save(doc.copyWith(content: '# Same')); // identical content

      expect(file.statSync().modified, mtimeBefore);
    });

    test('does rewrite the file when content actually changes', () async {
      final doc = await repo.save(
        _makeDoc(path: 'changing.md', content: '# Original', vaultId: vault.id),
      );
      final file = File(p.join(vaultRoot, 'changing.md'));
      final mtimeBefore = file.statSync().modified;

      await Future<void>.delayed(const Duration(milliseconds: 30));
      await repo.save(doc.copyWith(content: '# Changed'));

      expect(file.statSync().modified.isAfter(mtimeBefore), isTrue);
    });
  });

  group('ObsidianDocumentRepository — reading Obsidian-authored files', () {
    test('reads a note created externally, never touched by this repo', () async {
      const external = '---\n'
          'title: Written In Obsidian\n'
          'tags:\n'
          '  - personal\n'
          '  - ideas\n'
          'custom_field: keep-me\n'
          '---\n'
          '# Written In Obsidian\n\nSome body text.\n';
      final file = File(p.join(vaultRoot, 'Ideas', 'external_note.md'));
      await file.create(recursive: true);
      await file.writeAsString(external);

      final doc = await repo.getByPath('Ideas/external_note.md');
      expect(doc, isNotNull);
      expect(doc!.content, external); // untouched, verbatim
      expect(doc.title, 'Written In Obsidian');
      expect(doc.tags, containsAll(['personal', 'ideas']));
      expect(doc.frontmatter['custom_field'], 'keep-me');
    });

    test('derives title from filename when frontmatter has no title', () async {
      final file = File(p.join(vaultRoot, 'Untitled Note.md'));
      await file.create(recursive: true);
      await file.writeAsString('# Just a heading, no frontmatter\n');

      final doc = await repo.getByPath('Untitled Note.md');
      expect(doc!.title, 'Untitled Note');
    });

    test('preserves frontmatter exactly, including unusual key order', () async {
      const content = '---\n'
          'tags: [zeta]\n'
          'unknown_future_field: true\n'
          'title: Order Test\n'
          '---\n'
          'Body\n';
      await repo.save(_makeDoc(path: 'order.md', content: content, vaultId: vault.id));

      final onDisk = await File(p.join(vaultRoot, 'order.md')).readAsString();
      expect(onDisk, content); // exact byte match — nothing reordered
    });
  });

  group('ObsidianDocumentRepository — getAll', () {
    test('finds markdown files nested in subfolders', () async {
      await repo.save(_makeDoc(path: 'top.md', vaultId: vault.id));
      await repo.save(_makeDoc(path: 'Projects/nested.md', vaultId: vault.id));
      await repo.save(_makeDoc(path: 'Projects/Deep/deeper.md', vaultId: vault.id));

      final all = await repo.getAll();
      expect(all.map((d) => d.path).toSet(), {
        'top.md',
        'Projects/nested.md',
        'Projects/Deep/deeper.md',
      });
    });

    test('skips dot-directories such as .obsidian and .trash', () async {
      await repo.save(_makeDoc(path: 'real_note.md', vaultId: vault.id));

      final configFile = File(p.join(vaultRoot, '.obsidian', 'config.md'));
      await configFile.create(recursive: true);
      await configFile.writeAsString('{}');

      final trashedFile = File(p.join(vaultRoot, '.trash', 'deleted.md'));
      await trashedFile.create(recursive: true);
      await trashedFile.writeAsString('# Deleted note');

      final all = await repo.getAll();
      expect(all.map((d) => d.path), ['real_note.md']);
    });

    test('returns an empty list for a vault with no notes yet', () async {
      expect(await repo.getAll(), isEmpty);
    });
  });

  group('ObsidianDocumentRepository — DailyNoteService integration', () {
    test('creates a daily note that round-trips through the vault', () async {
      final created =
          await DailyNoteService.getOrCreate(repo, DateTime(2026, 7, 25), vault);
      expect(created.path, 'daily/2026-07-25.md');

      final onDisk =
          await File(p.join(vaultRoot, 'daily', '2026-07-25.md')).readAsString();
      expect(onDisk, created.content);

      final reloaded = await DailyNoteService.get(repo, DateTime(2026, 7, 25));
      expect(reloaded, isNotNull);
      expect(reloaded!.content, created.content);
    });

    test('getOrCreate does not rewrite an already-existing daily note', () async {
      await DailyNoteService.getOrCreate(repo, DateTime(2026, 7, 26), vault);
      final file = File(p.join(vaultRoot, 'daily', '2026-07-26.md'));
      final mtimeBefore = file.statSync().modified;

      await Future<void>.delayed(const Duration(milliseconds: 30));
      await DailyNoteService.getOrCreate(repo, DateTime(2026, 7, 26), vault);

      expect(file.statSync().modified, mtimeBefore);
    });

    test('loads a daily note that already exists as an Obsidian-authored file', () async {
      final externalDaily = '---\n'
          'title: Daily Note — July 27, 2026\n'
          'date: 2026-07-27\n'
          'tags: [daily]\n'
          '---\n\n'
          '## Written directly in Obsidian\n';
      final file = File(p.join(vaultRoot, 'daily', '2026-07-27.md'));
      await file.create(recursive: true);
      await file.writeAsString(externalDaily);

      final loaded = await DailyNoteService.get(repo, DateTime(2026, 7, 27));
      expect(loaded, isNotNull);
      expect(loaded!.content, externalDaily);
      expect(loaded.tags, contains('daily'));
    });
  });
}
