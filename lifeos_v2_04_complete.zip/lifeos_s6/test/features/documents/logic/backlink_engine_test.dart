import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/features/documents/data/document_model.dart';
import 'package:lifeos/features/documents/logic/backlink_engine.dart';

void main() {
  Document buildDocument({
    required String path,
    required String title,
    String content = '',
  }) {
    return Document(
      path: path,
      title: title,
      content: content,
      vaultId: 'internal',
      createdAt: DateTime(2025, 1, 1),
      updatedAt: DateTime(2025, 1, 2),
    );
  }

  group('BacklinkEngine.buildGraph', () {
    test(
        'mutual links, a shared target, and a broken link all resolve '
        'correctly across the whole vault in one pass',
        () {
      // a.md -> [[B]]
      // b.md -> [[A]], [[NonExistent]]
      // c.md -> [[B]]
      final docA = buildDocument(
        path: 'a.md',
        title: 'A',
        content: 'Links to [[B]].',
      );
      final docB = buildDocument(
        path: 'b.md',
        title: 'B',
        content: 'Links to [[A]] and [[NonExistent]].',
      );
      final docC = buildDocument(
        path: 'c.md',
        title: 'C',
        content: 'Also links to [[B]].',
      );

      final graph = BacklinkEngine.buildGraph([docA, docB, docC]);

      final aLinks = graph['a.md']!;
      expect(aLinks.outgoing.map((r) => r.document.path), ['b.md']);
      expect(aLinks.incoming.map((d) => d.path), ['b.md']);
      expect(aLinks.broken, isEmpty);

      final bLinks = graph['b.md']!;
      expect(bLinks.outgoing.map((r) => r.document.path), ['a.md']);
      expect(
        bLinks.incoming.map((d) => d.path).toSet(),
        {'a.md', 'c.md'},
      );
      expect(bLinks.broken.map((l) => l.target), ['NonExistent']);

      final cLinks = graph['c.md']!;
      expect(cLinks.outgoing.map((r) => r.document.path), ['b.md']);
      expect(cLinks.incoming, isEmpty); // nothing links to C
      expect(cLinks.broken, isEmpty);
    });

    test('a document referencing the same target twice contributes '
        'only one incoming entry to that target', () {
      final target = buildDocument(path: 'target.md', title: 'Target');
      final source = buildDocument(
        path: 'source.md',
        title: 'Source',
        content: 'See [[Target]] and again [[Target|here]].',
      );

      final graph = BacklinkEngine.buildGraph([target, source]);

      expect(graph['target.md']!.incoming, hasLength(1));
      expect(graph['target.md']!.incoming.single.path, 'source.md');
      // Outgoing is NOT deduplicated the same way — both occurrences
      // (with their own aliases) are preserved from the source's side.
      expect(graph['source.md']!.outgoing, hasLength(2));
    });

    test('a document with no links has empty outgoing/incoming/broken',
        () {
      final isolated = buildDocument(
        path: 'isolated.md',
        title: 'Isolated',
        content: 'No links here.',
      );

      final graph = BacklinkEngine.buildGraph([isolated]);

      final links = graph['isolated.md']!;
      expect(links.outgoing, isEmpty);
      expect(links.incoming, isEmpty);
      expect(links.broken, isEmpty);
    });

    test('a self-link is both outgoing and incoming for the same '
        'document', () {
      final doc = buildDocument(
        path: 'self.md',
        title: 'Self',
        content: 'Refers to [[Self]].',
      );

      final graph = BacklinkEngine.buildGraph([doc]);

      final links = graph['self.md']!;
      expect(links.outgoing.single.document.path, 'self.md');
      expect(links.incoming.single.path, 'self.md');
    });

    test('handles an empty document list', () {
      expect(BacklinkEngine.buildGraph(const []), isEmpty);
    });

    test('every broken link is reported, not just the first', () {
      final doc = buildDocument(
        path: 'a.md',
        title: 'A',
        content: 'See [[Missing1]] and [[Missing2]].',
      );

      final graph = BacklinkEngine.buildGraph([doc]);

      expect(
        graph['a.md']!.broken.map((l) => l.target).toList(),
        ['Missing1', 'Missing2'],
      );
    });
  });

  group('BacklinkEngine.linksFor', () {
    test('returns the graph entry for a known path', () {
      final doc = buildDocument(path: 'a.md', title: 'A');
      final graph = BacklinkEngine.buildGraph([doc]);

      final links = BacklinkEngine.linksFor('a.md', graph);

      expect(links, graph['a.md']);
    });

    test('returns DocumentLinks.empty for an unknown path', () {
      final graph = BacklinkEngine.buildGraph(const []);

      final links = BacklinkEngine.linksFor('missing.md', graph);

      expect(links.outgoing, isEmpty);
      expect(links.incoming, isEmpty);
      expect(links.broken, isEmpty);
    });
  });
}
