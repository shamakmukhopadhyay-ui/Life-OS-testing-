import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/features/documents/data/vault_model.dart';
import 'package:lifeos/features/documents/logic/daily_note_service.dart';

import '../../../helpers/fake_document_repository.dart';

void main() {
  late FakeDocumentRepository repo;
  const vault = Vault.defaultInternal;

  setUp(() {
    repo = FakeDocumentRepository();
  });

  group('DailyNoteService.dailyNotePath', () {
    test('pads single-digit month and day', () {
      expect(
        DailyNoteService.dailyNotePath(DateTime(2025, 1, 5)),
        'daily/2025-01-05.md',
      );
    });

    test('handles double-digit month and day', () {
      expect(
        DailyNoteService.dailyNotePath(DateTime(2025, 11, 30)),
        'daily/2025-11-30.md',
      );
    });

    test('produces consistent path for any date', () {
      final date = DateTime(2025, 7, 11);
      final path = DailyNoteService.dailyNotePath(date);
      expect(path, 'daily/2025-07-11.md');
      expect(path.endsWith('.md'), isTrue);
      expect(path.startsWith('daily/'), isTrue);
    });
  });

  group('DailyNoteService.get', () {
    test('returns null when no document exists', () async {
      final result =
          await DailyNoteService.get(repo, DateTime(2025, 7, 11));
      expect(result, isNull);
    });

    test('returns document when it exists', () async {
      // Pre-populate the repo.
      await DailyNoteService.getOrCreate(repo, DateTime(2025, 7, 11), vault);
      final result =
          await DailyNoteService.get(repo, DateTime(2025, 7, 11));
      expect(result, isNotNull);
      expect(result!.path, 'daily/2025-07-11.md');
    });
  });

  group('DailyNoteService.getOrCreate', () {
    test('creates a new document when none exists', () async {
      final result = await DailyNoteService.getOrCreate(
          repo, DateTime(2025, 7, 11), vault);

      expect(repo.saveCallCount, 1);
      expect(result.path, 'daily/2025-07-11.md');
      expect(result.vaultId, vault.id);
      expect(result.tags, contains('daily'));
    });

    test('returns existing document without creating a duplicate', () async {
      final first = await DailyNoteService.getOrCreate(
          repo, DateTime(2025, 7, 11), vault);
      repo.resetSaveCount();

      final second = await DailyNoteService.getOrCreate(
          repo, DateTime(2025, 7, 11), vault);

      expect(repo.saveCallCount, 0); // not saved again
      expect(second.path, first.path);
    });

    test('created note has frontmatter with title and date fields', () async {
      final result = await DailyNoteService.getOrCreate(
          repo, DateTime(2025, 7, 11), vault);

      expect(result.frontmatter.containsKey('title'), isTrue);
      expect(result.frontmatter.containsKey('date'), isTrue);
      expect(result.frontmatter['tags'], contains('daily'));
    });

    test('different dates produce different paths', () async {
      final a = await DailyNoteService.getOrCreate(
          repo, DateTime(2025, 7, 11), vault);
      final b = await DailyNoteService.getOrCreate(
          repo, DateTime(2025, 7, 12), vault);

      expect(a.path, isNot(b.path));
      expect(repo.saveCallCount, 2);
    });
  });
}
