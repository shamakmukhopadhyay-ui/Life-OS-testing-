import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/features/documents/data/document_model.dart';
import 'package:lifeos/features/documents/logic/document_management_service.dart';

import '../../../helpers/fake_document_repository.dart';

void main() {
  late FakeDocumentRepository repo;
  late DocumentManagementService service;
  late Document doc;

  setUp(() async {
    repo = FakeDocumentRepository();
    service = DocumentManagementService(repo);
    doc = Document(
      path: 'notes/My Note.md',
      vaultId: 'internal',
      title: 'My Note',
      content: '# Hello',
      tags: const ['ideas'],
      frontmatter: const {'title': 'My Note'},
      metadata: const {'source': 'test'},
      createdAt: DateTime(2025, 7, 11),
      updatedAt: DateTime(2025, 7, 11),
    );
    await repo.save(doc);
    repo.resetSaveCount();
  });

  group('DocumentManagementService.rename', () {
    test('updates the title and preserves the path', () async {
      final renamed = await service.rename(doc.path, 'New Title');

      expect(renamed.path, doc.path);
      expect(renamed.title, 'New Title');
      expect(repo.saveCallCount, 1);
    });

    test('bumps updatedAt and preserves createdAt', () async {
      final renamed = await service.rename(doc.path, 'New Title');

      expect(renamed.createdAt, doc.createdAt);
      expect(renamed.updatedAt.isAfter(doc.updatedAt), isTrue);
    });

    test('does NOT write when the new title is identical', () async {
      final result = await service.rename(doc.path, 'My Note');

      expect(repo.saveCallCount, 0);
      expect(result, doc);
    });

    test('does NOT write when the new title is blank', () async {
      final result = await service.rename(doc.path, '   ');

      expect(repo.saveCallCount, 0);
      expect(result, doc);
    });

    test('trims whitespace around the new title', () async {
      final renamed = await service.rename(doc.path, '  Trimmed  ');

      expect(renamed.title, 'Trimmed');
    });

    test('throws ArgumentError when the document does not exist', () async {
      await expectLater(
        service.rename('missing/nope.md', 'New Title'),
        throwsArgumentError,
      );
    });
  });

  group('DocumentManagementService.duplicate', () {
    test('creates a new document at a different path', () async {
      final copy = await service.duplicate(doc.path);

      expect(copy.path, isNot(doc.path));
      expect(repo.saveCallCount, 1);
      final all = await repo.getAll();
      expect(all.length, 2);
    });

    test('keeps the copy in the same folder as the original', () async {
      final copy = await service.duplicate(doc.path);

      expect(copy.path, startsWith('notes/'));
    });

    test('copies content, tags, frontmatter, and metadata verbatim',
        () async {
      final copy = await service.duplicate(doc.path);

      expect(copy.content, doc.content);
      expect(copy.tags, doc.tags);
      expect(copy.frontmatter, doc.frontmatter);
      expect(copy.metadata, doc.metadata);
    });

    test('appends " (Copy)" to the title', () async {
      final copy = await service.duplicate(doc.path);

      expect(copy.title, 'My Note (Copy)');
    });

    test('does not stack "(Copy)" when duplicating an existing copy',
        () async {
      final firstCopy = await service.duplicate(doc.path);
      final secondCopy = await service.duplicate(firstCopy.path);

      expect(secondCopy.title, 'My Note (Copy)');
    });

    test('resets backlinks on the copy', () async {
      // Overwrite the setUp doc (same path) with a variant that has
      // backlinks, then duplicate it.
      final withBacklinks = Document(
        path: doc.path,
        vaultId: doc.vaultId,
        title: doc.title,
        content: doc.content,
        backlinks: const ['other/page.md'],
        createdAt: doc.createdAt,
        updatedAt: doc.updatedAt,
      );
      await repo.save(withBacklinks);

      final copy = await service.duplicate(doc.path);

      expect(copy.backlinks, isEmpty);
    });

    test('gives the copy fresh createdAt/updatedAt timestamps', () async {
      final copy = await service.duplicate(doc.path);

      expect(copy.createdAt.isAfter(doc.createdAt), isTrue);
      expect(copy.updatedAt.isAfter(doc.updatedAt), isTrue);
    });

    test('throws ArgumentError when the source document does not exist',
        () async {
      await expectLater(
        service.duplicate('missing/nope.md'),
        throwsArgumentError,
      );
    });
  });
}
