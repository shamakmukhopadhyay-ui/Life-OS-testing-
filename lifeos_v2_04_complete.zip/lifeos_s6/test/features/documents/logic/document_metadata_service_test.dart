import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/features/documents/data/document_model.dart';
import 'package:lifeos/features/documents/logic/document_metadata_service.dart';

void main() {
  Document buildDocument(String content) {
    return Document(
      path: 'notes/example.md',
      title: 'Example (from Document.title)',
      content: content,
      vaultId: 'internal',
      createdAt: DateTime(2025, 3, 1),
      updatedAt: DateTime(2025, 4, 2),
    );
  }

  test('extracts metadata from well-formed frontmatter', () {
    // Content must start with '---' as its literal first line — no
    // leading blank line — or parseFrontmatter treats it as "no
    // frontmatter" and this test would silently check the wrong path.
    final doc = buildDocument('---\n'
        'title: Real Title\n'
        'type: journal\n'
        'tags: [reflection, morning]\n'
        'favorite: true\n'
        'pinned: false\n'
        'mood: calm\n'
        '---\n'
        '# Body\n'
        '\n'
        'Some content here.\n');

    final meta = DocumentMetadataService.parse(doc);

    expect(meta.title, 'Real Title');
    expect(meta.type, 'journal');
    expect(meta.tags, ['reflection', 'morning']);
    expect(meta.favorite, isTrue);
    expect(meta.pinned, isFalse);
    expect(meta.custom, {'mood': 'calm'});
  });

  test('falls back to Document fields when there is no frontmatter', () {
    final doc = buildDocument('# Just a heading\n\nNo frontmatter here.');

    final meta = DocumentMetadataService.parse(doc);

    expect(meta.title, doc.title);
    expect(meta.created, doc.createdAt);
    expect(meta.modified, doc.updatedAt);
    expect(meta.type, isNull);
    expect(meta.tags, isEmpty);
    expect(meta.favorite, isFalse);
    expect(meta.pinned, isFalse);
    expect(meta.custom, isEmpty);
  });

  test('falls back gracefully on malformed YAML rather than throwing', () {
    final doc = buildDocument('---\n'
        'title: "Unterminated quote\n'
        '---\n'
        'Body text.\n');

    expect(() => DocumentMetadataService.parse(doc), returnsNormally);

    final meta = DocumentMetadataService.parse(doc);
    // parseFrontmatter degrades malformed YAML to {}, so every field
    // falls back exactly as if there were no frontmatter at all.
    expect(meta.title, doc.title);
    expect(meta.created, doc.createdAt);
  });

  test('falls back gracefully when there is no closing delimiter', () {
    final doc = buildDocument('---\ntitle: Oops\nno closing line at all');

    final meta = DocumentMetadataService.parse(doc);
    expect(meta.title, doc.title);
  });

  test('does not require every known field to be present', () {
    final doc = buildDocument('---\ntitle: Just A Title\n---\nBody.');

    final meta = DocumentMetadataService.parse(doc);

    expect(meta.title, 'Just A Title');
    expect(meta.created, doc.createdAt); // fell back — not in frontmatter
    expect(meta.modified, doc.updatedAt); // fell back — not in frontmatter
  });

  test('parsing does not alter the original document', () {
    final original = buildDocument('---\ntitle: X\n---\nBody.');
    final contentBefore = original.content;

    DocumentMetadataService.parse(original);

    expect(original.content, contentBefore);
  });
}
