import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/features/documents/data/document_model.dart';
import 'package:lifeos/features/documents/logic/editor_provider.dart';

import '../../../helpers/fake_document_repository.dart';

void main() {
  late FakeDocumentRepository repo;
  late DocumentEditorService service;
  late Document doc;

  setUp(() {
    repo = FakeDocumentRepository();
    service = DocumentEditorService(repo);
    doc = Document(
      path: 'daily/2025-07-11.md',
      vaultId: 'internal',
      title: 'My Note',
      content: '# Hello',
      createdAt: DateTime(2025, 7, 11),
      updatedAt: DateTime(2025, 7, 11),
    );
  });

  group('DocumentEditorService.saveIfChanged', () {
    test('does NOT write to repo when nothing has changed', () async {
      final result = await service.saveIfChanged(
        current: doc,
        title: doc.title,
        content: doc.content,
      );

      expect(repo.saveCallCount, 0);
      expect(result, doc);
    });

    test('writes to repo when content changes', () async {
      const newContent = '# Updated';
      final result = await service.saveIfChanged(
        current: doc,
        title: doc.title,
        content: newContent,
      );

      expect(repo.saveCallCount, 1);
      expect(result.content, newContent);
    });

    test('writes to repo when title changes', () async {
      const newTitle = 'New Title';
      final result = await service.saveIfChanged(
        current: doc,
        title: newTitle,
        content: doc.content,
      );

      expect(repo.saveCallCount, 1);
      expect(result.title, newTitle);
    });

    test('falls back to existing title when provided title is blank', () async {
      final result = await service.saveIfChanged(
        current: doc,
        title: '   ',       // blank → should use doc.title
        content: '# New',   // content changed so save is triggered
      );

      expect(repo.saveCallCount, 1);
      expect(result.title, doc.title); // preserved
    });

    test('does NOT write when blank title + unchanged content', () async {
      // Blank title → cleanTitle = doc.title, content same → no change.
      final result = await service.saveIfChanged(
        current: doc,
        title: '   ',
        content: doc.content,
      );

      expect(repo.saveCallCount, 0);
      expect(result, doc);
    });

    test('prevents double-write when called twice with same new content',
        () async {
      const newContent = '# Changed';

      final first = await service.saveIfChanged(
        current: doc,
        title: doc.title,
        content: newContent,
      );

      // Second call — current is now the saved doc, same content.
      await service.saveIfChanged(
        current: first,
        title: first.title,
        content: newContent,
      );

      expect(repo.saveCallCount, 1); // only the first call should write
    });
  });
}
