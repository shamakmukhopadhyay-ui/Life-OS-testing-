import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/features/documents/data/document_model.dart';
import 'package:lifeos/features/documents/logic/file_change_detector.dart';

void main() {
  Document doc(String path, String content) {
    return Document(
      path: path,
      title: 'Title',
      content: content,
      vaultId: 'obsidian',
      createdAt: DateTime(2025, 1, 1),
      updatedAt: DateTime(2025, 1, 2),
    );
  }

  late FileChangeDetector detector;

  setUp(() {
    detector = FileChangeDetector();
  });

  group('FileChangeDetector — baseline tracking', () {
    test('hasBaseline is false before anything is recorded', () {
      expect(detector.hasBaseline('notes/a.md'), isFalse);
    });

    test('hasBaseline is true after recording', () {
      detector.recordKnownState(doc('notes/a.md', 'content'));
      expect(detector.hasBaseline('notes/a.md'), isTrue);
    });

    test('knownPathCount reflects the number of recorded paths', () {
      expect(detector.knownPathCount, 0);
      detector.recordKnownState(doc('notes/a.md', 'x'));
      detector.recordKnownState(doc('notes/b.md', 'y'));
      expect(detector.knownPathCount, 2);
    });

    test('recording the same path twice does not double-count it', () {
      detector.recordKnownState(doc('notes/a.md', 'first'));
      detector.recordKnownState(doc('notes/a.md', 'second'));
      expect(detector.knownPathCount, 1);
    });
  });

  group('FileChangeDetector — hasChangedSinceRecorded', () {
    test('is false when content is unchanged since recording', () {
      final original = doc('notes/a.md', 'same content');
      detector.recordKnownState(original);

      final rereadUnchanged = doc('notes/a.md', 'same content');
      expect(detector.hasChangedSinceRecorded(rereadUnchanged), isFalse);
    });

    test('is true when content differs from the recorded baseline', () {
      detector.recordKnownState(doc('notes/a.md', 'original content'));

      final editedExternally = doc('notes/a.md', 'edited content');
      expect(detector.hasChangedSinceRecorded(editedExternally), isTrue);
    });

    test('is false — not true — when there is no baseline at all', () {
      // "Never seen before" is a distinct claim from "changed"; a
      // document with no recorded baseline should not be reported as
      // having changed.
      final neverRecorded = doc('notes/never-seen.md', 'anything');
      expect(detector.hasChangedSinceRecorded(neverRecorded), isFalse);
    });

    test('tracks multiple paths independently', () {
      detector.recordKnownState(doc('notes/a.md', 'a-content'));
      detector.recordKnownState(doc('notes/b.md', 'b-content'));

      final aChanged = doc('notes/a.md', 'a-content-modified');
      final bUnchanged = doc('notes/b.md', 'b-content');

      expect(detector.hasChangedSinceRecorded(aChanged), isTrue);
      expect(detector.hasChangedSinceRecorded(bUnchanged), isFalse);
    });

    test('recording again after a change resets the baseline', () {
      detector.recordKnownState(doc('notes/a.md', 'v1'));
      final v2 = doc('notes/a.md', 'v2');
      expect(detector.hasChangedSinceRecorded(v2), isTrue);

      detector.recordKnownState(v2); // acknowledge the new state
      expect(detector.hasChangedSinceRecorded(v2), isFalse);
    });
  });

  group('FileChangeDetector — forget/reset', () {
    test('forget removes a single path\'s baseline', () {
      detector.recordKnownState(doc('notes/a.md', 'x'));
      detector.recordKnownState(doc('notes/b.md', 'y'));

      detector.forget('notes/a.md');

      expect(detector.hasBaseline('notes/a.md'), isFalse);
      expect(detector.hasBaseline('notes/b.md'), isTrue);
    });

    test('reset clears every recorded baseline', () {
      detector.recordKnownState(doc('notes/a.md', 'x'));
      detector.recordKnownState(doc('notes/b.md', 'y'));

      detector.reset();

      expect(detector.knownPathCount, 0);
      expect(detector.hasBaseline('notes/a.md'), isFalse);
    });
  });
}
