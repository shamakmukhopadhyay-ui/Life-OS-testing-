import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/features/documents/data/document_model.dart';
import 'package:lifeos/features/documents/logic/metadata_query_service.dart';

void main() {
  Document buildDocument({
    required String path,
    required String title,
    String frontmatterBody = '',
  }) {
    final content = frontmatterBody.isEmpty
        ? '# $title\n\nNo frontmatter.'
        : '---\n$frontmatterBody---\n# $title\n';
    return Document(
      path: path,
      title: title,
      content: content,
      vaultId: 'internal',
      createdAt: DateTime(2025, 1, 1),
      updatedAt: DateTime(2025, 1, 2),
    );
  }

  final favoriteDoc = buildDocument(
    path: 'notes/a.md',
    title: 'Favorite Note',
    frontmatterBody: 'favorite: true\n',
  );
  final pinnedDoc = buildDocument(
    path: 'notes/b.md',
    title: 'Pinned Note',
    frontmatterBody: 'pinned: true\n',
  );
  final journalDoc = buildDocument(
    path: 'notes/c.md',
    title: 'Journal Entry',
    frontmatterBody: 'type: journal\n',
  );
  final taggedDoc = buildDocument(
    path: 'notes/d.md',
    title: 'Tagged Note',
    frontmatterBody: 'tags: [work, urgent]\n',
  );
  final plainDoc = buildDocument(path: 'notes/e.md', title: 'Plain Note');

  final allDocs = [favoriteDoc, pinnedDoc, journalDoc, taggedDoc, plainDoc];

  group('MetadataQueryService.withMetadata', () {
    test('produces one entry per document, in the same order', () {
      final paired = MetadataQueryService.withMetadata(allDocs);

      expect(paired.length, allDocs.length);
      for (var i = 0; i < allDocs.length; i++) {
        expect(paired[i].document, allDocs[i]);
      }
    });

    test('correctly parses each metadata field', () {
      final paired = MetadataQueryService.withMetadata([favoriteDoc]);
      expect(paired.single.metadata.favorite, isTrue);
    });

    test('handles an empty document list', () {
      expect(MetadataQueryService.withMetadata(const []), isEmpty);
    });
  });

  group('MetadataQueryService.favorites', () {
    test('returns only documents with favorite: true', () {
      final result =
          MetadataQueryService.favorites(MetadataQueryService.withMetadata(allDocs));

      expect(result, [favoriteDoc]);
    });

    test('returns empty when nothing is favorited', () {
      final result = MetadataQueryService.favorites(
        MetadataQueryService.withMetadata([pinnedDoc, journalDoc, plainDoc]),
      );

      expect(result, isEmpty);
    });
  });

  group('MetadataQueryService.pinned', () {
    test('returns only documents with pinned: true', () {
      final result =
          MetadataQueryService.pinned(MetadataQueryService.withMetadata(allDocs));

      expect(result, [pinnedDoc]);
    });

    test('returns empty when nothing is pinned', () {
      final result = MetadataQueryService.pinned(
        MetadataQueryService.withMetadata([favoriteDoc, journalDoc, plainDoc]),
      );

      expect(result, isEmpty);
    });
  });

  group('MetadataQueryService.byType', () {
    test('returns only documents matching the given type', () {
      final result = MetadataQueryService.byType(
        MetadataQueryService.withMetadata(allDocs),
        'journal',
      );

      expect(result, [journalDoc]);
    });

    test('returns empty when no document has that type', () {
      final result = MetadataQueryService.byType(
        MetadataQueryService.withMetadata(allDocs),
        'project',
      );

      expect(result, isEmpty);
    });

    test('is case-sensitive', () {
      final result = MetadataQueryService.byType(
        MetadataQueryService.withMetadata(allDocs),
        'Journal',
      );

      expect(result, isEmpty);
    });
  });

  group('MetadataQueryService.byTag', () {
    test('returns documents containing the given tag', () {
      final result = MetadataQueryService.byTag(
        MetadataQueryService.withMetadata(allDocs),
        'work',
      );

      expect(result, [taggedDoc]);
    });

    test('returns empty when no document has that tag', () {
      final result = MetadataQueryService.byTag(
        MetadataQueryService.withMetadata(allDocs),
        'personal',
      );

      expect(result, isEmpty);
    });
  });

  group('MetadataQueryService — documents without frontmatter', () {
    test('never match favorite, pinned, or a type filter', () {
      final paired = MetadataQueryService.withMetadata([plainDoc]);

      expect(MetadataQueryService.favorites(paired), isEmpty);
      expect(MetadataQueryService.pinned(paired), isEmpty);
      expect(MetadataQueryService.byType(paired, 'journal'), isEmpty);
      expect(MetadataQueryService.byTag(paired, 'anything'), isEmpty);
    });
  });
}
