import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/features/documents/data/document_model.dart';
import 'package:lifeos/features/documents/data/vault_model.dart';
import 'package:lifeos/features/documents/logic/obsidian_launcher_service.dart';

void main() {
  Document doc(String path) {
    return Document(
      path: path,
      title: 'Title',
      content: 'content',
      vaultId: 'v1',
      createdAt: DateTime(2025, 1, 1),
      updatedAt: DateTime(2025, 1, 2),
    );
  }

  const obsidianVault = Vault(
    id: 'v1',
    name: 'My Vault',
    type: VaultType.obsidian,
    rootPath: '/home/user/My Vault',
  );

  group('ObsidianLauncherService.buildLaunchRequest — outcomes', () {
    test('reports noActiveVault when vault is null', () {
      final result = ObsidianLauncherService.buildLaunchRequest(
        document: doc('a.md'),
        vault: null,
      );

      expect(result.outcome, ObsidianLaunchOutcome.noActiveVault);
      expect(result.uri, isNull);
    });

    test('reports notAnObsidianVault for an internal vault', () {
      final result = ObsidianLauncherService.buildLaunchRequest(
        document: doc('a.md'),
        vault: Vault.defaultInternal,
      );

      expect(result.outcome, ObsidianLaunchOutcome.notAnObsidianVault);
      expect(result.uri, isNull);
    });

    test('reports launchUnavailable (with a URI) for an Obsidian vault',
        () {
      final result = ObsidianLauncherService.buildLaunchRequest(
        document: doc('notes/a.md'),
        vault: obsidianVault,
      );

      expect(result.outcome, ObsidianLaunchOutcome.launchUnavailable);
      expect(result.uri, isNotNull);
    });
  });

  group('ObsidianLauncherService.buildLaunchRequest — URI construction', () {
    test('uses the open action with vault and file parameters', () {
      final result = ObsidianLauncherService.buildLaunchRequest(
        document: doc('notes/idea.md'),
        vault: obsidianVault,
      );

      expect(result.uri, startsWith('obsidian://open?'));
      expect(result.uri, contains('vault='));
      expect(result.uri, contains('file='));
    });

    test('omits the .md extension from the file parameter', () {
      final result = ObsidianLauncherService.buildLaunchRequest(
        document: doc('notes/idea.md'),
        vault: obsidianVault,
      );

      // The encoded path segment should not end in the encoded '.md'.
      expect(result.uri, isNot(contains('idea.md')));
      expect(result.uri, contains(Uri.encodeComponent('notes/idea')));
    });

    test('leaves a non-.md path (defensively) untouched', () {
      final result = ObsidianLauncherService.buildLaunchRequest(
        document: doc('notes/idea.canvas'),
        vault: obsidianVault,
      );

      expect(
        result.uri,
        contains(Uri.encodeComponent('notes/idea.canvas')),
      );
    });

    test('percent-encodes spaces in the vault name and file path', () {
      const spacedVault = Vault(
        id: 'v2',
        name: 'My Vault',
        type: VaultType.obsidian,
        rootPath: '/vaults/My Vault',
      );
      final result = ObsidianLauncherService.buildLaunchRequest(
        document: doc('notes/My Idea.md'),
        vault: spacedVault,
      );

      expect(result.uri, contains('vault=My%20Vault'));
      expect(result.uri, contains('file=notes%2FMy%20Idea'));
    });

    test('percent-encodes forward slashes in a nested file path', () {
      final result = ObsidianLauncherService.buildLaunchRequest(
        document: doc('daily/2026/07-27.md'),
        vault: obsidianVault,
      );

      // A raw, un-encoded '/' inside the file value would be ambiguous
      // per Obsidian's own documentation — every '/' from the path
      // must appear as %2F.
      final fileParam = result.uri!.split('file=').last;
      expect(fileParam, isNot(contains('/')));
      expect(fileParam, contains('%2F'));
    });

    test('is case-insensitive about the .md suffix', () {
      final result = ObsidianLauncherService.buildLaunchRequest(
        document: doc('notes/idea.MD'),
        vault: obsidianVault,
      );

      expect(result.uri, isNot(contains('.MD')));
      expect(result.uri, isNot(contains('.md')));
    });
  });
}
