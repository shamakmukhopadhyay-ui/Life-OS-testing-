import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/features/documents/data/document_model.dart';
import 'package:lifeos/features/documents/logic/metadata_query_service.dart';
import 'package:lifeos/features/documents/logic/search_service.dart';

void main() {
  Document buildDocument({
    required String path,
    required String title,
    String frontmatterBody = '',
    String body = 'Body text.',
  }) {
    final content = frontmatterBody.isEmpty
        ? body
        : '---\n$frontmatterBody---\n$body';
    return Document(
      path: path,
      title: title,
      content: content,
      vaultId: 'internal',
      createdAt: DateTime(2025, 1, 1),
      updatedAt: DateTime(2025, 1, 2),
    );
  }

  DocumentWithMetadata withMeta(Document doc) {
    return MetadataQueryService.withMetadata([doc]).single;
  }

  group('SearchService.matchesTitle', () {
    test('matches case-insensitively', () {
      final doc = withMeta(buildDocument(path: 'a.md', title: 'Meeting Notes'));
      expect(SearchService.matchesTitle(doc, 'meeting'), isTrue);
      expect(SearchService.matchesTitle(doc, 'MEETING'), isTrue);
    });

    test('does not match unrelated text', () {
      final doc = withMeta(buildDocument(path: 'a.md', title: 'Meeting Notes'));
      expect(SearchService.matchesTitle(doc, 'grocery'), isFalse);
    });
  });

  group('SearchService.matchesContent', () {
    test('matches text in the body', () {
      final doc = withMeta(buildDocument(
        path: 'a.md',
        title: 'Untitled',
        body: 'Remember to buy milk and eggs.',
      ));
      expect(SearchService.matchesContent(doc, 'milk'), isTrue);
      expect(SearchService.matchesContent(doc, 'bread'), isFalse);
    });

    test('matches text inside the frontmatter block too', () {
      // Content is still just text — frontmatter isn't excluded from a
      // content search, since it's literally part of the file's text.
      final doc = withMeta(buildDocument(
        path: 'a.md',
        title: 'Untitled',
        frontmatterBody: 'author: Jane Doe\n',
      ));
      expect(SearchService.matchesContent(doc, 'Jane'), isTrue);
    });
  });

  group('SearchService.matchesMetadata', () {
    test('matches the type field', () {
      final doc = withMeta(buildDocument(
        path: 'a.md',
        title: 'Untitled',
        frontmatterBody: 'type: journal\n',
      ));
      expect(SearchService.matchesMetadata(doc, 'journal'), isTrue);
    });

    test('matches a tag', () {
      final doc = withMeta(buildDocument(
        path: 'a.md',
        title: 'Untitled',
        frontmatterBody: 'tags: [work, urgent]\n',
      ));
      expect(SearchService.matchesMetadata(doc, 'urgent'), isTrue);
    });

    test('matches a custom property value', () {
      final doc = withMeta(buildDocument(
        path: 'a.md',
        title: 'Untitled',
        frontmatterBody: 'mood: adventurous\n',
      ));
      expect(SearchService.matchesMetadata(doc, 'adventurous'), isTrue);
    });

    test('does not match when nothing in metadata matches', () {
      final doc = withMeta(buildDocument(
        path: 'a.md',
        title: 'Untitled',
        frontmatterBody: 'type: journal\ntags: [work]\n',
      ));
      expect(SearchService.matchesMetadata(doc, 'zzz-nomatch'), isFalse);
    });

    test('handles a document with no frontmatter gracefully', () {
      final doc = withMeta(buildDocument(path: 'a.md', title: 'Untitled'));
      expect(SearchService.matchesMetadata(doc, 'anything'), isFalse);
    });
  });

  group('SearchService.matches', () {
    test('is true if any of title/content/metadata matches', () {
      final doc = withMeta(buildDocument(
        path: 'a.md',
        title: 'Groceries',
        frontmatterBody: 'tags: [errands]\n',
        body: 'Milk, eggs, bread.',
      ));
      expect(SearchService.matches(doc, 'groceries'), isTrue); // title
      expect(SearchService.matches(doc, 'eggs'), isTrue); // content
      expect(SearchService.matches(doc, 'errands'), isTrue); // metadata
      expect(SearchService.matches(doc, 'zzz-nomatch'), isFalse);
    });
  });

  group('SearchService.search', () {
    test('returns only matching documents as plain Documents', () {
      final a = buildDocument(path: 'a.md', title: 'Meeting Notes');
      final b = buildDocument(path: 'b.md', title: 'Grocery List');
      final withMetadata = MetadataQueryService.withMetadata([a, b]);

      final result = SearchService.search(withMetadata, 'meeting');

      expect(result, [a]);
    });

    test('returns an empty list for a blank query', () {
      final a = buildDocument(path: 'a.md', title: 'Meeting Notes');
      final withMetadata = MetadataQueryService.withMetadata([a]);

      expect(SearchService.search(withMetadata, ''), isEmpty);
      expect(SearchService.search(withMetadata, '   '), isEmpty);
    });

    test('returns an empty list when nothing matches', () {
      final a = buildDocument(path: 'a.md', title: 'Meeting Notes');
      final withMetadata = MetadataQueryService.withMetadata([a]);

      expect(SearchService.search(withMetadata, 'zzz-nomatch'), isEmpty);
    });

    test('trims surrounding whitespace from the query', () {
      final a = buildDocument(path: 'a.md', title: 'Meeting Notes');
      final withMetadata = MetadataQueryService.withMetadata([a]);

      expect(SearchService.search(withMetadata, '  meeting  '), [a]);
    });
  });

  group('SearchService.snippetFor', () {
    test('returns null for a blank query', () {
      final doc = buildDocument(path: 'a.md', title: 'x', body: 'some text');
      expect(SearchService.snippetFor(doc, ''), isNull);
    });

    test('returns null when the query is not in the content', () {
      final doc = buildDocument(path: 'a.md', title: 'x', body: 'some text');
      expect(SearchService.snippetFor(doc, 'zzz-nomatch'), isNull);
    });

    test('the returned snippet contains the match at the reported '
        'position', () {
      final doc = buildDocument(
        path: 'a.md',
        title: 'x',
        body: 'A' * 100 + 'meeting' + 'B' * 100,
      );

      final snippet = SearchService.snippetFor(doc, 'meeting');

      expect(snippet, isNotNull);
      expect(
        snippet!.text.substring(
          snippet.matchStart,
          snippet.matchStart + snippet.matchLength,
        ),
        'meeting',
      );
    });

    test('does not prefix with an ellipsis when the match is near the '
        'start', () {
      final doc = buildDocument(
        path: 'a.md',
        title: 'x',
        body: 'meeting notes ${'B' * 200}',
      );

      final snippet = SearchService.snippetFor(doc, 'meeting');

      expect(snippet, isNotNull);
      expect(snippet!.text.startsWith('…'), isFalse);
      expect(
        snippet.text.substring(
          snippet.matchStart,
          snippet.matchStart + snippet.matchLength,
        ),
        'meeting',
      );
    });

    test('does not suffix with an ellipsis when the match is near the '
        'end', () {
      final doc = buildDocument(
        path: 'a.md',
        title: 'x',
        body: '${'A' * 200} meeting',
      );

      final snippet = SearchService.snippetFor(doc, 'meeting');

      expect(snippet, isNotNull);
      expect(snippet!.text.endsWith('…'), isFalse);
    });

    test('is case-insensitive', () {
      final doc = buildDocument(path: 'a.md', title: 'x', body: 'MEETING notes');
      final snippet = SearchService.snippetFor(doc, 'meeting');
      expect(snippet, isNotNull);
    });
  });

  group('SearchService.tagCounts', () {
    test('counts how many documents carry each tag', () {
      final docs = [
        buildDocument(
          path: 'a.md',
          title: 'A',
          frontmatterBody: 'tags: [work, urgent]\n',
        ),
        buildDocument(
          path: 'b.md',
          title: 'B',
          frontmatterBody: 'tags: [work]\n',
        ),
        buildDocument(path: 'c.md', title: 'C'),
      ];
      final withMetadata = MetadataQueryService.withMetadata(docs);

      final result = SearchService.tagCounts(withMetadata);
      // TagCount has no custom ==, matching DocumentWithMetadata's own
      // precedent, so compare extracted (tag, count) pairs instead of
      // whole-object equality.
      final pairs = [for (final t in result) (t.tag, t.count)];

      expect(pairs, [('urgent', 1), ('work', 2)]);
    });

    test('returns an empty list when no document has any tags', () {
      final docs = [buildDocument(path: 'a.md', title: 'A')];
      final withMetadata = MetadataQueryService.withMetadata(docs);

      expect(SearchService.tagCounts(withMetadata), isEmpty);
    });

    test('is sorted alphabetically by tag', () {
      final docs = [
        buildDocument(
          path: 'a.md',
          title: 'A',
          frontmatterBody: 'tags: [zebra, apple, mango]\n',
        ),
      ];
      final withMetadata = MetadataQueryService.withMetadata(docs);

      final result = SearchService.tagCounts(withMetadata);

      expect(result.map((t) => t.tag).toList(), ['apple', 'mango', 'zebra']);
    });
  });
}
