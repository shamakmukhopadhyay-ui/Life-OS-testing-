import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/features/documents/data/document_model.dart';
import 'package:lifeos/features/documents/logic/file_change_detector.dart';
import 'package:lifeos/features/documents/logic/vault_sync_service.dart';

void main() {
  Document doc(String path, String content) {
    return Document(
      path: path,
      title: 'Title',
      content: content,
      vaultId: 'obsidian',
      createdAt: DateTime(2025, 1, 1),
      updatedAt: DateTime(2025, 1, 2),
    );
  }

  late FileChangeDetector detector;

  setUp(() {
    detector = FileChangeDetector();
  });

  group('VaultSyncService.recordBaseline', () {
    test('records a baseline for every document in the list', () {
      final docs = [doc('a.md', '1'), doc('b.md', '2'), doc('c.md', '3')];

      VaultSyncService.recordBaseline(docs, detector);

      expect(detector.knownPathCount, 3);
      for (final d in docs) {
        expect(detector.hasBaseline(d.path), isTrue);
      }
    });

    test('handles an empty list without error', () {
      expect(
        () => VaultSyncService.recordBaseline(const [], detector),
        returnsNormally,
      );
      expect(detector.knownPathCount, 0);
    });
  });

  group('VaultSyncService.findFilesNeedingReindex', () {
    test('returns empty when nothing changed since the baseline', () {
      final docs = [doc('a.md', '1'), doc('b.md', '2')];
      VaultSyncService.recordBaseline(docs, detector);

      final result = VaultSyncService.findFilesNeedingReindex(docs, detector);

      expect(result, isEmpty);
    });

    test('returns only the paths whose content changed', () {
      final original = [doc('a.md', '1'), doc('b.md', '2'), doc('c.md', '3')];
      VaultSyncService.recordBaseline(original, detector);

      final fresh = [
        doc('a.md', '1'), // unchanged
        doc('b.md', 'CHANGED'), // changed externally
        doc('c.md', '3'), // unchanged
      ];

      final result = VaultSyncService.findFilesNeedingReindex(fresh, detector);

      expect(result, ['b.md']);
    });

    test('excludes documents with no recorded baseline', () {
      // Deliberately does not call recordBaseline first — every one of
      // these is "unknown," not "changed," per FileChangeDetector's own
      // contract, so none should be reported as needing re-indexing.
      final docs = [doc('a.md', '1'), doc('b.md', '2')];

      final result = VaultSyncService.findFilesNeedingReindex(docs, detector);

      expect(result, isEmpty);
    });

    test('returns empty for an empty document list', () {
      expect(VaultSyncService.findFilesNeedingReindex(const [], detector),
          isEmpty);
    });

    test('a full record-then-check-then-record cycle converges to empty',
        () {
      final v1 = [doc('a.md', 'v1'), doc('b.md', 'v1')];
      VaultSyncService.recordBaseline(v1, detector);

      final v2 = [doc('a.md', 'v2'), doc('b.md', 'v1')];
      expect(
        VaultSyncService.findFilesNeedingReindex(v2, detector),
        ['a.md'],
      );

      // After "handling" the change, the caller re-records the baseline.
      VaultSyncService.recordBaseline(v2, detector);
      expect(VaultSyncService.findFilesNeedingReindex(v2, detector), isEmpty);
    });
  });
}
