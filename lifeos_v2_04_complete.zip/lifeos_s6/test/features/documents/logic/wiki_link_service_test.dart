import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/features/documents/data/document_model.dart';
import 'package:lifeos/features/documents/logic/wiki_link_service.dart';

void main() {
  Document buildDocument({required String path, required String title}) {
    return Document(
      path: path,
      title: title,
      content: 'content',
      vaultId: 'internal',
      createdAt: DateTime(2025, 1, 1),
      updatedAt: DateTime(2025, 1, 2),
    );
  }

  group('WikiLinkService.extractLinks — the four required formats', () {
    test('[[Page]]', () {
      final links = WikiLinkService.extractLinks('See [[Page]] for more.');
      expect(links, hasLength(1));
      expect(links.single.target, 'Page');
      expect(links.single.alias, isNull);
      expect(links.single.displayText, 'Page');
    });

    test('[[Page|Alias]]', () {
      final links = WikiLinkService.extractLinks('See [[Page|Alias]].');
      expect(links, hasLength(1));
      expect(links.single.target, 'Page');
      expect(links.single.alias, 'Alias');
      expect(links.single.displayText, 'Alias');
    });

    test('[[Folder/Page]]', () {
      final links = WikiLinkService.extractLinks('[[Folder/Page]]');
      expect(links.single.target, 'Folder/Page');
      expect(links.single.alias, isNull);
    });

    test('[[Folder/Page|Alias]]', () {
      final links = WikiLinkService.extractLinks('[[Folder/Page|Alias]]');
      expect(links.single.target, 'Folder/Page');
      expect(links.single.alias, 'Alias');
    });

    test('multiple links in one document, in order', () {
      final links = WikiLinkService.extractLinks(
        'First [[A]], then [[B|Bee]], then [[C/D]].',
      );
      expect(links.map((l) => l.target).toList(), ['A', 'B', 'C/D']);
      expect(links.map((l) => l.alias).toList(), [null, 'Bee', null]);
    });
  });

  group('WikiLinkService.extractLinks — malformed links are ignored', () {
    test('empty brackets', () {
      expect(WikiLinkService.extractLinks('[[]]'), isEmpty);
    });

    test('whitespace-only target', () {
      expect(WikiLinkService.extractLinks('[[   ]]'), isEmpty);
    });

    test('empty target before a pipe', () {
      expect(WikiLinkService.extractLinks('[[|Alias]]'), isEmpty);
    });

    test('unclosed brackets', () {
      expect(WikiLinkService.extractLinks('[[Page and no closing'), isEmpty);
    });

    test('single brackets are not wiki links', () {
      expect(WikiLinkService.extractLinks('[not a link]'), isEmpty);
    });

    test('a truly empty alias does not match at all', () {
      // Verified empirically before writing this: the alias character
      // class also requires 1+ characters, so [[Page|]] never matches
      // the pattern — it isn't "a link with alias null", it's simply
      // not a match, same bucket as [[]] and [[|Alias]].
      expect(WikiLinkService.extractLinks('[[Page|]]'), isEmpty);
    });

    test('a whitespace-only alias normalizes to no alias, not to a '
        'literal-whitespace alias', () {
      final links = WikiLinkService.extractLinks('[[Page| ]]');
      expect(links, hasLength(1));
      expect(links.single.target, 'Page');
      expect(links.single.alias, isNull);
    });
  });

  group('WikiLinkService.resolve — path/basename/title fallback', () {
    test('resolves an exact folder-qualified path', () {
      final target = buildDocument(path: 'notes/Idea.md', title: 'My Idea');
      final index = DocumentIndex([target]);

      final resolved = WikiLinkService.resolve(
        const WikiLink(target: 'notes/Idea'),
        index,
      );

      expect(resolved, target);
    });

    test('resolves a bare name by basename, regardless of folder', () {
      final target = buildDocument(path: 'deeply/nested/Idea.md', title: 'x');
      final index = DocumentIndex([target]);

      final resolved = WikiLinkService.resolve(
        const WikiLink(target: 'Idea'),
        index,
      );

      expect(resolved, target);
    });

    test('basename matching is case-insensitive', () {
      final target = buildDocument(path: 'notes/Idea.md', title: 'x');
      final index = DocumentIndex([target]);

      final resolved = WikiLinkService.resolve(
        const WikiLink(target: 'IDEA'),
        index,
      );

      expect(resolved, target);
    });

    test('falls back to title when path/basename do not match', () {
      final target = buildDocument(path: 'a1b2c3.md', title: 'My Great Idea');
      final index = DocumentIndex([target]);

      final resolved = WikiLinkService.resolve(
        const WikiLink(target: 'My Great Idea'),
        index,
      );

      expect(resolved, target);
    });

    test('title matching is case-insensitive', () {
      final target = buildDocument(path: 'a1b2c3.md', title: 'My Great Idea');
      final index = DocumentIndex([target]);

      final resolved = WikiLinkService.resolve(
        const WikiLink(target: 'my great idea'),
        index,
      );

      expect(resolved, target);
    });

    test('returns null when nothing matches — a broken link', () {
      final other = buildDocument(path: 'notes/other.md', title: 'Other');
      final index = DocumentIndex([other]);

      final resolved = WikiLinkService.resolve(
        const WikiLink(target: 'Nonexistent Page'),
        index,
      );

      expect(resolved, isNull);
    });

    test('an explicit .md extension in the target is not doubled', () {
      final target = buildDocument(path: 'notes/Idea.md', title: 'x');
      final index = DocumentIndex([target]);

      final resolved = WikiLinkService.resolve(
        const WikiLink(target: 'notes/Idea.md'),
        index,
      );

      expect(resolved, target);
    });

    test('prefers an exact path match over a basename match', () {
      final exact = buildDocument(path: 'notes/Idea.md', title: 'Exact');
      final elsewhere =
          buildDocument(path: 'archive/Idea.md', title: 'Elsewhere');
      final index = DocumentIndex([exact, elsewhere]);

      final resolved = WikiLinkService.resolve(
        const WikiLink(target: 'notes/Idea'),
        index,
      );

      expect(resolved, exact);
    });
  });
}
