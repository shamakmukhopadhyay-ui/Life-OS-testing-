import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/features/focus/data/focus_session_model.dart';

void main() {
  group('FocusSession.idle', () {
    test('remainingTime equals the full duration', () {
      expect(FocusSession.idle.remainingTime, const Duration(minutes: 25));
    });

    test('progress is zero', () {
      expect(FocusSession.idle.progress, 0.0);
    });

    test('status flags', () {
      expect(FocusSession.idle.isIdle, isTrue);
      expect(FocusSession.idle.isRunning, isFalse);
      expect(FocusSession.idle.isPaused, isFalse);
      expect(FocusSession.idle.isCompleted, isFalse);
    });
  });

  group('FocusSession — running', () {
    test('remainingTime decreases with elapsed active time', () {
      final session = FocusSession(
        durationMinutes: 25,
        startTime: DateTime.now().subtract(const Duration(minutes: 10)),
        status: FocusSessionStatus.running,
      );

      final remaining = session.remainingTime;
      // .inMinutes truncates toward zero, and some time always passes
      // between constructing startTime and evaluating remainingTime,
      // so this is deterministically 14, never 15 — not an
      // approximation that could flake.
      expect(remaining.inMinutes, 14);
    });

    test('remainingTime never goes negative once overdue', () {
      final session = FocusSession(
        durationMinutes: 25,
        startTime: DateTime.now().subtract(const Duration(minutes: 40)),
        status: FocusSessionStatus.running,
      );

      expect(session.remainingTime, Duration.zero);
    });

    test('progress reflects elapsed fraction of the total', () {
      final session = FocusSession(
        durationMinutes: 20,
        startTime: DateTime.now().subtract(const Duration(minutes: 10)),
        status: FocusSessionStatus.running,
      );

      expect(session.progress, closeTo(0.5, 0.05));
    });
  });

  group('FocusSession — paused freezes remaining time', () {
    test(
        'the exact traced scenario: paused at 5 elapsed minutes stays at '
        '20 remaining regardless of how long the pause itself lasts',
        () {
      final startTime = DateTime.now().subtract(const Duration(minutes: 15));
      // Paused 5 minutes after starting — 10 minutes ago from "now",
      // meaning the pause itself has already lasted 10 real minutes.
      final pausedAt = startTime.add(const Duration(minutes: 5));

      final session = FocusSession(
        durationMinutes: 25,
        startTime: startTime,
        status: FocusSessionStatus.paused,
        pausedAt: pausedAt,
      );

      // Frozen at exactly 25 - 5 = 20 minutes, unaffected by the 10
      // real minutes that have passed since pausedAt.
      expect(session.remainingTime.inMinutes, 20);
    });

    test('resuming preserves the frozen remaining time at the instant '
        'of resume', () {
      final startTime = DateTime.now().subtract(const Duration(minutes: 15));
      final pausedAt = startTime.add(const Duration(minutes: 5));
      final paused = FocusSession(
        durationMinutes: 25,
        startTime: startTime,
        status: FocusSessionStatus.paused,
        pausedAt: pausedAt,
      );

      // Manually compute what resume() would produce, to test the
      // model's own arithmetic independent of FocusService.
      final additionalPause = DateTime.now().difference(pausedAt);
      final resumed = FocusSession(
        durationMinutes: paused.durationMinutes,
        startTime: paused.startTime,
        status: FocusSessionStatus.running,
        pausedDuration: paused.pausedDuration + additionalPause,
      );

      expect(resumed.remainingTime.inMinutes, 20);
    });
  });

  group('FocusSession.completed', () {
    test('remainingTime is zero and progress is 1.0', () {
      const session = FocusSession(
        durationMinutes: 25,
        status: FocusSessionStatus.completed,
      );

      expect(session.remainingTime, Duration.zero);
      expect(session.progress, 1.0);
    });
  });

  group('FocusSession JSON round-trip', () {
    test('idle session round-trips', () {
      const session = FocusSession.idle;
      final decoded = FocusSession.fromJson(session.toJson());

      expect(decoded.durationMinutes, session.durationMinutes);
      expect(decoded.status, session.status);
      expect(decoded.startTime, session.startTime);
    });

    test('a running session with all fields set round-trips exactly', () {
      final session = FocusSession(
        durationMinutes: 45,
        startTime: DateTime(2026, 1, 15, 10, 30),
        status: FocusSessionStatus.paused,
        pausedDuration: const Duration(minutes: 3, seconds: 20),
        pausedAt: DateTime(2026, 1, 15, 10, 40),
      );

      final decoded = FocusSession.fromJson(session.toJson());

      expect(decoded.durationMinutes, 45);
      expect(decoded.startTime, DateTime(2026, 1, 15, 10, 30));
      expect(decoded.status, FocusSessionStatus.paused);
      expect(decoded.pausedDuration, const Duration(minutes: 3, seconds: 20));
      expect(decoded.pausedAt, DateTime(2026, 1, 15, 10, 40));
    });

    test('missing pausedSeconds defaults to zero rather than throwing', () {
      final json = FocusSession.idle.toJson()..remove('pausedSeconds');
      final decoded = FocusSession.fromJson(json);

      expect(decoded.pausedDuration, Duration.zero);
    });
  });
}
