import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/features/focus/data/focus_session_model.dart';
import 'package:lifeos/features/focus/logic/focus_service.dart';

void main() {
  group('FocusService.start', () {
    test('produces a running session with the requested duration', () {
      final session = FocusService.start(45);

      expect(session.isRunning, isTrue);
      expect(session.durationMinutes, 45);
      expect(session.startTime, isNotNull);
      expect(session.pausedDuration, Duration.zero);
    });

    test('starting always begins fresh, even from a completed session',
        () {
      final session = FocusService.start(25);
      expect(session.pausedAt, isNull);
      expect(session.remainingTime, const Duration(minutes: 25));
    });
  });

  group('FocusService.pause', () {
    test('running becomes paused', () {
      final running = FocusService.start(25);
      final paused = FocusService.pause(running);

      expect(paused.isPaused, isTrue);
      expect(paused.pausedAt, isNotNull);
      expect(paused.startTime, running.startTime);
    });

    test('is a no-op when not running', () {
      expect(FocusService.pause(FocusSession.idle), FocusSession.idle);

      const completed = FocusSession(status: FocusSessionStatus.completed);
      expect(FocusService.pause(completed).status, FocusSessionStatus.completed);
    });
  });

  group('FocusService.resume', () {
    test('paused becomes running and accumulates the pause length', () {
      final startTime = DateTime.now().subtract(const Duration(minutes: 15));
      final pausedAt = startTime.add(const Duration(minutes: 5));
      final paused = FocusSession(
        durationMinutes: 25,
        startTime: startTime,
        status: FocusSessionStatus.paused,
        pausedAt: pausedAt,
      );

      final resumed = FocusService.resume(paused);

      expect(resumed.isRunning, isTrue);
      expect(resumed.pausedAt, isNull);
      // The pause lasted ~10 real minutes (pausedAt was 10 minutes ago).
      expect(resumed.pausedDuration.inMinutes, 10);
      // Frozen-at-pause remaining time (20 min) is preserved immediately
      // after resuming — the exact scenario traced by hand while
      // designing the model.
      expect(resumed.remainingTime.inMinutes, 20);
    });

    test('is a no-op when not paused', () {
      expect(FocusService.resume(FocusSession.idle), FocusSession.idle);

      final running = FocusService.start(25);
      expect(FocusService.resume(running), running);
    });
  });

  group('FocusService.stop', () {
    test('returns idle from running', () {
      final running = FocusService.start(25);
      expect(FocusService.stop(running), FocusSession.idle);
    });

    test('returns idle from paused', () {
      final paused = FocusService.pause(FocusService.start(25));
      expect(FocusService.stop(paused), FocusSession.idle);
    });
  });

  group('FocusService.reset', () {
    test('returns idle from completed', () {
      const completed = FocusSession(status: FocusSessionStatus.completed);
      expect(FocusService.reset(completed), FocusSession.idle);
    });

    test('returns idle from any other state too', () {
      expect(FocusService.reset(FocusService.start(25)), FocusSession.idle);
    });
  });

  group('FocusService.checkForCompletion', () {
    test('transitions an overdue running session to completed', () {
      final overdue = FocusSession(
        durationMinutes: 25,
        startTime: DateTime.now().subtract(const Duration(minutes: 30)),
        status: FocusSessionStatus.running,
      );

      final result = FocusService.checkForCompletion(overdue);

      expect(result.isCompleted, isTrue);
    });

    test('leaves a running session with time left unchanged', () {
      final stillRunning = FocusSession(
        durationMinutes: 25,
        startTime: DateTime.now().subtract(const Duration(minutes: 5)),
        status: FocusSessionStatus.running,
      );

      final result = FocusService.checkForCompletion(stillRunning);

      expect(result.isRunning, isTrue);
    });

    test('leaves idle/paused/completed sessions unchanged', () {
      expect(FocusService.checkForCompletion(FocusSession.idle), FocusSession.idle);

      final paused = FocusService.pause(FocusService.start(25));
      expect(FocusService.checkForCompletion(paused), paused);
    });
  });
}
