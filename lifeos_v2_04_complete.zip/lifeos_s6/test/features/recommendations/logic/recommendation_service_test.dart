import 'package:flutter_test/flutter_test.dart';
import 'package:lifeos/features/recommendations/logic/recommendation_service.dart';
import 'package:lifeos/features/recommendations/data/recommendation_model.dart';
import 'package:lifeos/features/score/data/daily_score_result.dart';

void main() {
  const allClear = RecommendationInputs(
    remainingTaskCount: 0,
    hasFocusSessionToday: true,
    dailyNoteHasContent: true,
    dailyScoreStatus: DailyStatus.excellent,
  );

  group('RecommendationService.generate', () {
    test('returns an empty list when nothing needs attention', () {
      expect(RecommendationService.generate(allClear), isEmpty);
    });

    test('recommends clearing tasks at the "many" threshold (5)', () {
      const inputs = RecommendationInputs(
        remainingTaskCount: 5,
        hasFocusSessionToday: true,
        dailyNoteHasContent: true,
        dailyScoreStatus: DailyStatus.excellent,
      );
      final result = RecommendationService.generate(inputs);
      expect(result, hasLength(1));
      expect(result.single.recommendationType, RecommendationType.tasks);
      expect(result.single.priority, RecommendationPriority.high);
    });

    test('does not fire the tasks rule just below the threshold', () {
      const inputs = RecommendationInputs(
        remainingTaskCount: 4,
        hasFocusSessionToday: true,
        dailyNoteHasContent: true,
        dailyScoreStatus: DailyStatus.excellent,
      );
      expect(RecommendationService.generate(inputs), isEmpty);
    });

    test('recommends objectives when the daily score needs improvement',
        () {
      const inputs = RecommendationInputs(
        remainingTaskCount: 0,
        hasFocusSessionToday: true,
        dailyNoteHasContent: true,
        dailyScoreStatus: DailyStatus.needsImprovement,
      );
      final result = RecommendationService.generate(inputs);
      expect(result, hasLength(1));
      expect(
        result.single.recommendationType,
        RecommendationType.objectives,
      );
      expect(result.single.priority, RecommendationPriority.high);
    });

    test('recommends a focus session when none was started today', () {
      const inputs = RecommendationInputs(
        remainingTaskCount: 0,
        hasFocusSessionToday: false,
        dailyNoteHasContent: true,
        dailyScoreStatus: DailyStatus.excellent,
      );
      final result = RecommendationService.generate(inputs);
      expect(result, hasLength(1));
      expect(result.single.recommendationType, RecommendationType.focus);
      expect(result.single.priority, RecommendationPriority.medium);
    });

    test("recommends writing today's note when it has no content", () {
      const inputs = RecommendationInputs(
        remainingTaskCount: 0,
        hasFocusSessionToday: true,
        dailyNoteHasContent: false,
        dailyScoreStatus: DailyStatus.excellent,
      );
      final result = RecommendationService.generate(inputs);
      expect(result, hasLength(1));
      expect(result.single.recommendationType, RecommendationType.dailyNote);
      expect(result.single.priority, RecommendationPriority.medium);
    });

    test('caps at 3, preferring high priority over medium when 4 rules '
        'fire at once', () {
      const inputs = RecommendationInputs(
        remainingTaskCount: 10, // high: tasks
        hasFocusSessionToday: false, // medium: focus
        dailyNoteHasContent: false, // medium: dailyNote
        dailyScoreStatus: DailyStatus.needsImprovement, // high: objectives
      );
      final result = RecommendationService.generate(inputs);

      expect(result, hasLength(3));
      expect(
        result.where((r) => r.priority == RecommendationPriority.high),
        hasLength(2),
      );
      expect(
        result.where((r) => r.priority == RecommendationPriority.medium),
        hasLength(1),
      );
      // Both high-priority rules made it in; only one of the two
      // medium ones did — which one isn't asserted, since List.sort
      // isn't guaranteed stable for equal-priority items.
      expect(
        result.any((r) => r.recommendationType == RecommendationType.tasks),
        isTrue,
      );
      expect(
        result.any(
          (r) => r.recommendationType == RecommendationType.objectives,
        ),
        isTrue,
      );
    });

    test('ids are stable per rule, not per call', () {
      const inputs = RecommendationInputs(
        remainingTaskCount: 5,
        hasFocusSessionToday: true,
        dailyNoteHasContent: true,
        dailyScoreStatus: DailyStatus.excellent,
      );
      final first = RecommendationService.generate(inputs).single.id;
      final second = RecommendationService.generate(inputs).single.id;
      expect(first, second);
    });
  });
}
