import 'package:lifeos/features/documents/data/document_model.dart';
import 'package:lifeos/features/documents/data/document_repository.dart';

/// An in-memory [DocumentRepository] for unit tests.
///
/// Stores documents in a [Map]. Tracks [saveCallCount] so tests can
/// assert that the repository was (or was not) written to.
class FakeDocumentRepository implements DocumentRepository {
  final Map<String, Document> _store = {};
  int saveCallCount = 0;

  void resetSaveCount() => saveCallCount = 0;

  @override
  Future<Document?> getByPath(String path) async => _store[path];

  @override
  Future<Document> save(Document document) async {
    saveCallCount++;
    _store[document.path] = document;
    return document;
  }

  @override
  Future<List<Document>> getAll() async => _store.values.toList();

  @override
  Future<List<Document>> getByTag(String tag) async =>
      _store.values.where((d) => d.tags.contains(tag)).toList();

  @override
  Future<List<Document>> search(String query) async => _store.values
      .where((d) =>
          d.title.contains(query) || d.content.contains(query))
      .toList();

  @override
  Future<void> delete(String path) async => _store.remove(path);

  @override
  Future<bool> exists(String path) async => _store.containsKey(path);
}
